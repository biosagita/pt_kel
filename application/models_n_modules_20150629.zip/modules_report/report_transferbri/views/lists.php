<div class="row page-header">
    <h3>Report Transfer BRI</h3>
</div>

<div class="row">
    <?php if(isset($error)) : ?>
        <div class="alert alert-danger">
            <?php echo $error; ?>
        </div>
    <?php endif; ?>
    <form class="form-inline" role="form" action="<?php echo site_url('report/transfer-bri'); ?>">
        <div class="form-group">
            <label for="txt_tanggal_awal">Tanggal Awal:</label>
            <input class="datepicker form-control" id="txt_tanggal_awal" name="txt_tanggal_awal" value="<?php echo (!empty($txt_tanggal_awal) ? $txt_tanggal_awal : ''); ?>">
        </div>
        <div class="form-group">
            <label for="txt_tanggal_akhir">Tanggal Akhir:</label>
            <input class="datepicker form-control" id="txt_tanggal_akhir" name="txt_tanggal_akhir" value="<?php echo (!empty($txt_tanggal_akhir) ? $txt_tanggal_akhir : ''); ?>">
        </div>
        <button type="submit" class="btn btn-default">Submit</button>
        <?php if(!empty($periode)): ?>
        <a href="<?php echo site_url('report/transfer-bri/export?txt_tanggal_awal=' . $txt_tanggal_awal . '&txt_tanggal_akhir=' . $txt_tanggal_akhir); ?>" class="btn btn-success"><span class="glyphicon glyphicon-star" aria-hidden="true"></span> Export Excel</a> <a target="_blank" href="<?php echo site_url('report/transfer-bri/print?txt_tanggal_awal=' . $txt_tanggal_awal . '&txt_tanggal_akhir=' . $txt_tanggal_akhir); ?>" class="btn btn-primary"><span class="glyphicon glyphicon-star" aria-hidden="true"></span> Print</a>
        <?php endif; ?>
    </form>
</div>

<?php if(!empty($periode)): ?>
<div class="row report">
    <p>KANTOR IMIGRASI KELAS I JAKARTA UTARA<br />UNTUK TANGGAL : <?php echo $periode; ?></p>
    <div class="table-responsive">
        <table class="table table-striped table-bordered table-condensed">
            <thead class="gray">
                <tr>
                    <th>NO.</th>
                    <th>NAMA / NIP</th>
                    <th>NOMOR REKENING</th>
                    <th>NETTO</th>
                </tr>
                <tr>
                    <th>1</th>
                    <th>2</th>
                    <th>3</th>
                    <th>4</th>
                </tr>
            </thead>
            <tbody>
                <?php 
                    $total = 0;
                ?>
                <?php foreach($result as $key => $val) : ?>
                <?php 
                    $netto = !empty($potongan[$val['id_karyawan']]) ? ($val['tunjangan'] - $potongan[$val['id_karyawan']]) : $val['tunjangan'];
                    $total += $netto;
                ?>
                <tr>
                    <td><?php echo ($key+1); ?></td>
                    <td><div style="text-align:left;"><?php echo $val['nama_lengkap']; ?><br />NIP. <?php echo $val['nip']; ?></div></td>
                    <td><?php echo $val['norek']; ?></td>
                    <td><div style="text-align:right;"><?php echo (!empty($netto) ? (number_format($netto, 0, ',', '.')) : '-'); ?></div></td>
                </tr>
                <?php endforeach; ?>
                <tr class="jumlah">
                    <td>Jumlah</td>
                    <td></td>
                    <td></td>
                    <td><div style="text-align:right;"><?php echo (!empty($total) ? (number_format($total, 0, ',', '.')) : '-'); ?></div></td>
                </tr>
            </tbody>
        </table>
    </div>
</div>
<?php endif; ?>