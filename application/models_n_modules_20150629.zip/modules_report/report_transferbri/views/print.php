<?php if(!empty($periode)): ?>
<div class="row report">
    <p>KANTOR IMIGRASI KELAS I JAKARTA UTARA<br />UNTUK TANGGAL : <?php echo $periode; ?></p>
    <div class="table-responsive">
        <table class="table table-striped table-bordered table-condensed">
            <thead class="gray">
                <tr>
                    <th>NO.</th>
                    <th>NAMA / NIP</th>
                    <th>NOMOR REKENING</th>
                    <th>NETTO</th>
                </tr>
                <tr>
                    <th>1</th>
                    <th>2</th>
                    <th>3</th>
                    <th>4</th>
                </tr>
            </thead>
            <tbody>
                <?php 
                    $total = 0;
                ?>
                <?php foreach($result as $key => $val) : ?>
                <?php 
                    $netto = !empty($potongan[$val['id_karyawan']]) ? ($val['tunjangan'] - $potongan[$val['id_karyawan']]) : $val['tunjangan'];
                    $total += $netto;
                ?>
                <tr>
                    <td><?php echo ($key+1); ?></td>
                    <td><div style="text-align:left;"><?php echo $val['nama_lengkap']; ?><br />NIP. <?php echo $val['nip']; ?></div></td>
                    <td><?php echo $val['norek']; ?></td>
                    <td><div style="text-align:right;"><?php echo (!empty($netto) ? (number_format($netto, 0, ',', '.')) : '-'); ?></div></td>
                </tr>
                <?php endforeach; ?>
                <tr class="jumlah">
                    <td>Jumlah</td>
                    <td></td>
                    <td></td>
                    <td><div style="text-align:right;"><?php echo (!empty($total) ? (number_format($total, 0, ',', '.')) : '-'); ?></div></td>
                </tr>
            </tbody>
        </table>
    </div>
</div>
<?php endif; ?>