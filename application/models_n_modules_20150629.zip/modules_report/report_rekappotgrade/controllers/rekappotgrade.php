<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Rekappotgrade extends MY_Report {

	function __construct(){
		parent::__construct();

		$this->load->model('report_model', 'report');
	}
	
	function index() {
		if(!empty($_GET['txt_tanggal_awal']) AND !empty($_GET['txt_tanggal_akhir'])) {
			$this->do_submit();
		}

		$this->template->set('title', 'Rekap Pot Grade');
		$this->template->set('assets', $this->_data['assets']);
		$this->template->load('template_report/main', 'lists', $this->_data);
	}

	private function do_submit() {
		$this->_data['txt_tanggal_awal'] 	= $_GET['txt_tanggal_awal'];
		$this->_data['txt_tanggal_akhir'] 	= $_GET['txt_tanggal_akhir'];

		$strtotime_tanggal_awal 	= strtotime($this->_data['txt_tanggal_awal']);
		$strtotime_tanggal_akhir 	= strtotime($this->_data['txt_tanggal_akhir']);

		if($strtotime_tanggal_awal > $strtotime_tanggal_akhir) {
			$this->_data['error'] = '<p>Tanggal akhir harus lebih sama dengan tanggal awal</p>';
			return false;
		}

		$this->_data['periode'] = date('d F Y', $strtotime_tanggal_awal) . ' s/d ' . date('d F Y', $strtotime_tanggal_akhir);
		$this->_data['result_potongan_masuk_1'] = $this->report->get_all_potongan_masuk_1();
		$this->_data['result_potongan_masuk_2'] = $this->report->get_all_potongan_masuk_2();
		$this->_data['result_potongan_gakmasuk'] = $this->report->get_all_potongan_gakmasuk();
		$this->_data['result_grade'] = $this->report->get_all_grade();
		$this->_data['result'] = $this->report->get_all_karyawan_grade();
		$this->_data['result_karyawan'] = $this->report->get_all_karyawan();
		$this->get_netto_karyawan();
	}

	function export_excel() {
		$this->do_submit();
		
		//load our new PHPExcel library
		$this->load->library('excel');
		//activate worksheet number 1
		$this->excel->setActiveSheetIndex(0);
		//name the worksheet
		$this->excel->getActiveSheet()->setTitle('Transfer BRI');

		$this->excel->getDefaultStyle()->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
		$this->excel->getDefaultStyle()->getFont()->setSize(8);

		$style_border = array(
		  'borders' => array(
		    'allborders' => array(
		      'style' => PHPExcel_Style_Border::BORDER_THIN
		    )
		  )
		);

		$style_color = array(
            'fill' => array(
                'type' => PHPExcel_Style_Fill::FILL_SOLID,
                'color' => array('rgb' => 'AAA8AD')
            )
        );

		$this->excel->getActiveSheet()->setCellValue('A1', 'KEMENTERIAN HUKUM DAN HAM');
		$this->excel->getActiveSheet()->setCellValue('A2', 'REPUBLIK INDONESIA');
		$this->excel->getActiveSheet()->setCellValue('A3', 'KANTOR IMIGRASI KELAS I JAKARTA UTARA');

		$default_row = 5;

		$first = true;
		foreach($this->_data['result_grade'] as $valGrade) {
			if(!empty($this->_data['result'][$valGrade['kelas_grade']])) {
				//if(!$first) break;
				//if($first) $first = false;

				$cnt_row_label1 = !empty($next_row) ? (4 + $next_row) : $default_row;
				
				$this->excel->getActiveSheet()->setCellValue(('A'.$cnt_row_label1), 'REKAP POTONGAN ABSENSI TANGGAL '.$this->_data['periode']);
				$this->excel->getActiveSheet()->setCellValue(('A'.++$cnt_row_label1), 'GRADE ' . $valGrade['kelas_grade']);

				$this->excel->getActiveSheet()->setCellValue(('A'.++$cnt_row_label1), 'NO');
				$this->excel->getActiveSheet()->setCellValue(('B'.$cnt_row_label1), 'NAMA/NIP');
				$this->excel->getActiveSheet()->setCellValue(('C'.$cnt_row_label1), 'KETERANGAN ABSEN');

				$this->excel->getActiveSheet()->setCellValue(('A'.($cnt_row_label1+5)), 1);
				$this->excel->getActiveSheet()->setCellValue(('B'.($cnt_row_label1+5)), 2);

				$cnt_no = 3;

				$last_row_label = $cnt_row_label1;

				$row_label = $cnt_row_label1 + 1;

				$last_char = '';

				$next_char = 'C';
				foreach($this->_data['result_potongan_masuk_1'] as $val) {
					$this->excel->getActiveSheet()->setCellValue(($next_char.$row_label), $val['sp_nama']);
					$this->excel->getActiveSheet()->setCellValue(($next_char.($row_label+2)), $val['persentase']);
					$this->excel->getActiveSheet()->setCellValue(($next_char.($row_label+3)), number_format(round(($valGrade['tunjangan'] / 100) * $val['persentase']), 0, '.', ','));
					$this->excel->getActiveSheet()->setCellValue(($next_char.($row_label+4)), $cnt_no);
					$last_char = $next_char;
					$next_char++;
					$cnt_no++;
				}

				$next_char2 = $next_char;

				$next_char_potongan_1 = $next_char;
				$this->excel->getActiveSheet()->setCellValue(($next_char_potongan_1.$row_label), 'TERLAMBAT MASUK KERJA TANPA IZIN/ALASAN YANG SAH');

				$row_label_x = $row_label + 1;

				$jenis_sanksi = array();
				foreach($this->_data['result_potongan_masuk_2'] as $val) {
					$jenis_sanksi[$val['jp_kode']][$val['sp_izin_status']][$val['id_sanksi_potongan']] = 1;

					$this->excel->getActiveSheet()->setCellValue(($next_char2.$row_label_x), ($val['sp_nama'] . ' (' . (!empty($val['sp_menit_akhir']) ? ('Menit ' . $val['sp_menit_awal'] . '-' . $val['sp_menit_akhir']) : ('> ' . $val['sp_menit_awal'])) . ')'));

					$this->excel->getActiveSheet()->setCellValue(($next_char2.($row_label_x+1)), $val['persentase']);
					$this->excel->getActiveSheet()->setCellValue(($next_char2.($row_label_x+2)), number_format(round(($valGrade['tunjangan'] / 100) * $val['persentase']), 0, '.', ','));
					$this->excel->getActiveSheet()->setCellValue(($next_char2.($row_label_x+3)), $cnt_no);

					$last_char = $next_char2;
					$next_char2++;
					$cnt_no++;
				}

				//merge keterangan absen
				$this->excel->getActiveSheet()->mergeCells(('C'.$cnt_row_label1).':'.($last_char.$cnt_row_label1));

				//merge keterangan absen satu satu
				$next_char_potongan_1_y = chr((ord($next_char_potongan_1)+(count($jenis_sanksi['MT'][0])-1)));
				$next_char_potongan_2_x = ord($next_char_potongan_1_y)+1;
				$next_char_potongan_2_y = chr(($next_char_potongan_2_x+(count($jenis_sanksi['MT'][1])-1)));
				$next_char_potongan_3_x = ord($next_char_potongan_2_y)+1;
				$next_char_potongan_3_y = chr(($next_char_potongan_3_x+(count($jenis_sanksi['PC'][0])-1)));
				$next_char_potongan_4_x = ord($next_char_potongan_3_y)+1;
				$next_char_potongan_4_y = chr(($next_char_potongan_4_x+(count($jenis_sanksi['PC'][1])-1)));


				$this->excel->getActiveSheet()->setCellValue((chr($next_char_potongan_2_x).$row_label), 'TERLAMBAT MASUK KERJA DENGAN IZIN/ALASAN YANG SAH');
				$this->excel->getActiveSheet()->setCellValue((chr($next_char_potongan_3_x).$row_label), 'PULANG LEBIH AWAL TANPA IZIN/ALASAN YANG SAH');
				$this->excel->getActiveSheet()->setCellValue((chr($next_char_potongan_4_x).$row_label), 'PULANG LEBIH AWAL DENGAN IZIN/ALASAN YANG SAH');

				$this->excel->getActiveSheet()->mergeCells(($next_char_potongan_1.$row_label).':'.($next_char_potongan_1_y.$row_label));
				$this->excel->getActiveSheet()->mergeCells((chr($next_char_potongan_2_x).$row_label).':'.($next_char_potongan_2_y.$row_label));
				$this->excel->getActiveSheet()->mergeCells((chr($next_char_potongan_3_x).$row_label).':'.($next_char_potongan_3_y.$row_label));
				$this->excel->getActiveSheet()->mergeCells((chr($next_char_potongan_4_x).$row_label).':'.($next_char_potongan_4_y.$row_label));

				$next_char3 = $next_char2;

				foreach($this->_data['result_potongan_gakmasuk'] as $val) {
					$this->excel->getActiveSheet()->setCellValue(($next_char3.$last_row_label), $val['sp_nama']);
					$this->excel->getActiveSheet()->setCellValue(($next_char3.($last_row_label+3)), $val['persentase']);
					$this->excel->getActiveSheet()->setCellValue(($next_char3.($last_row_label+4)), number_format(round(($valGrade['tunjangan'] / 100) * $val['persentase']), 0, '.', ','));
					$this->excel->getActiveSheet()->setCellValue(($next_char3.($last_row_label+5)), $cnt_no);
					$next_char3++;
					$cnt_no++;
				}

				$this->excel->getActiveSheet()->setCellValue(($next_char3.$last_row_label), 'TOTAL POTONGAN');
				$this->excel->getActiveSheet()->setCellValue(($next_char3.($last_row_label+5)), $cnt_no);

				$this->excel->getActiveSheet()->setCellValue((++$next_char3.$last_row_label), 'TOTAL TERIMA TUNKER');
				$this->excel->getActiveSheet()->setCellValue(($next_char3.($last_row_label+4)), number_format($valGrade['tunjangan'], 0, '.', ','));
				$this->excel->getActiveSheet()->setCellValue(($next_char3.($last_row_label+5)), ++$cnt_no);

				//echo content table
                $total_potongan = 0;
                $total_terima = 0;
                $jumlah_potongan = array();

				$content_row = $last_row_label+6;
				$no = 0;
				foreach($this->_data['result'][$valGrade['kelas_grade']] as $keyKaryawan => $valKaryawan) {
					$this->excel->getActiveSheet()->setCellValue(('A'.($content_row + $no)), ($no+1));
					$this->excel->getActiveSheet()->setCellValue(('B'.($content_row + $no)), ($valKaryawan['nama_lengkap'] . ' NIP. ' . $valKaryawan['nip']));

					$next_char = 'C';
					foreach($this->_data['result_potongan_masuk_1'] as $val) {
						$tmp_potongan = !empty($this->_data['potongan_2'][$valKaryawan['id_karyawan']][$val['id_sanksi_potongan']]) ? $this->_data['potongan_2'][$valKaryawan['id_karyawan']][$val['id_sanksi_potongan']] : 0;
                        if(empty($jumlah_potongan[$val['id_sanksi_potongan']])) {
                            $jumlah_potongan[$val['id_sanksi_potongan']] = $tmp_potongan;
                        } else {
                            $jumlah_potongan[$val['id_sanksi_potongan']] += $tmp_potongan;
                        }

						$this->excel->getActiveSheet()->setCellValue(($next_char.($content_row + $no)), (!empty($tmp_potongan) ? number_format($tmp_potongan, 0, '.', ',') : '-'));
						$next_char++;
					}

					$next_char2 = $next_char;
					foreach($this->_data['result_potongan_masuk_2'] as $val) {
						$tmp_potongan = !empty($this->_data['potongan_2'][$valKaryawan['id_karyawan']][$val['id_sanksi_potongan']]) ? $this->_data['potongan_2'][$valKaryawan['id_karyawan']][$val['id_sanksi_potongan']] : 0;
                        if(empty($jumlah_potongan[$val['id_sanksi_potongan']])) {
                            $jumlah_potongan[$val['id_sanksi_potongan']] = $tmp_potongan;
                        } else {
                            $jumlah_potongan[$val['id_sanksi_potongan']] += $tmp_potongan;
                        }

						$this->excel->getActiveSheet()->setCellValue(($next_char2.($content_row + $no)), (!empty($tmp_potongan) ? number_format($tmp_potongan, 0, '.', ',') : '-'));
						$next_char2++;
					}

					$next_char3 = $next_char2;
					foreach($this->_data['result_potongan_gakmasuk'] as $val) {
						$tmp_potongan = !empty($this->_data['potongan_2'][$valKaryawan['id_karyawan']][$val['id_sanksi_potongan']]) ? $this->_data['potongan_2'][$valKaryawan['id_karyawan']][$val['id_sanksi_potongan']] : 0;
                        if(empty($jumlah_potongan[$val['id_sanksi_potongan']])) {
                            $jumlah_potongan[$val['id_sanksi_potongan']] = $tmp_potongan;
                        } else {
                            $jumlah_potongan[$val['id_sanksi_potongan']] += $tmp_potongan;
                        }

						$this->excel->getActiveSheet()->setCellValue(($next_char3.($content_row + $no)), (!empty($tmp_potongan) ? number_format($tmp_potongan, 0, '.', ',') : '-'));
						$next_char3++;
					}

					$this->excel->getActiveSheet()->setCellValue(($next_char3.($content_row + $no)), (!empty($this->_data['potongan'][$valKaryawan['id_karyawan']]) ? number_format($this->_data['potongan'][$valKaryawan['id_karyawan']], 0, '.', ',') : '-'));

					$jumlah_terima = $valKaryawan['tunjangan'] - $this->_data['potongan'][$valKaryawan['id_karyawan']];

					$this->excel->getActiveSheet()->setCellValue((++$next_char3.($content_row + $no)), (!empty($jumlah_terima) ? number_format($jumlah_terima, 0, '.', ',') : '-'));

					$total_potongan += $this->_data['potongan'][$valKaryawan['id_karyawan']];
                    $total_terima += $jumlah_terima;

					$no++;
				}

				$this->excel->getActiveSheet()->setCellValue(('A'.($content_row + $no)), 'Jumlah');

				$next_char = 'C';
				foreach($this->_data['result_potongan_masuk_1'] as $val) {
					$this->excel->getActiveSheet()->setCellValue(($next_char.($content_row + $no)), (!empty($jumlah_potongan[$val['id_sanksi_potongan']]) ? number_format($jumlah_potongan[$val['id_sanksi_potongan']], 0, '.', ',') : '-'));
					$next_char++;
				}

				$next_char2 = $next_char;
				foreach($this->_data['result_potongan_masuk_2'] as $val) {
					$this->excel->getActiveSheet()->setCellValue(($next_char2.($content_row + $no)), (!empty($jumlah_potongan[$val['id_sanksi_potongan']]) ? number_format($jumlah_potongan[$val['id_sanksi_potongan']], 0, '.', ',') : '-'));
					$next_char2++;
				}

				$next_char3 = $next_char2;
				foreach($this->_data['result_potongan_gakmasuk'] as $val) {
					$this->excel->getActiveSheet()->setCellValue(($next_char3.($content_row + $no)), (!empty($jumlah_potongan[$val['id_sanksi_potongan']]) ? number_format($jumlah_potongan[$val['id_sanksi_potongan']], 0, '.', ',') : '-'));
					$next_char3++;
				}

				$this->excel->getActiveSheet()->setCellValue(($next_char3.($content_row + $no)), (!empty($total_potongan) ? number_format($total_potongan, 0, '.', ',') : '-'));
				$this->excel->getActiveSheet()->setCellValue((++$next_char3.($content_row + $no)), (!empty($total_terima) ? number_format($total_terima, 0, '.', ',') : '-'));

				$next_row = $content_row + $no;

				$this->excel->getActiveSheet()->getStyle('A'.$cnt_row_label1.':'.($next_char3.($content_row + $no)))->applyFromArray($style_border);
			}
		}

		$filename='report_rekap_pot_grade_'.time().'.xls'; //save our workbook as this file name
		header('Content-Type: application/vnd.ms-excel'); //mime type
		header('Content-Disposition: attachment;filename="'.$filename.'"'); //tell browser what's the file name
		header('Cache-Control: max-age=0'); //no cache
		            
		//save it to Excel5 format (excel 2003 .XLS file), change this to 'Excel2007' (and adjust the filename extension, also the header mime type)
		//if you want to save it as .XLSX Excel 2007 format
		$objWriter = PHPExcel_IOFactory::createWriter($this->excel, 'Excel5');  
		//force user to download the Excel file without writing it to server's HD
		$objWriter->save('php://output');
	}

	private function get_netto_karyawan() {
		$strtotime_tanggal_awal 	= strtotime(($this->_data['txt_tanggal_awal'] . ' 00:00:00'));
		$strtotime_tanggal_akhir 	= strtotime(($this->_data['txt_tanggal_akhir'] . ' 23:59:00'));

		$res_potongan 		= $this->report->get_all_sanksipotongan();
		$res_potongan_masuk = $this->report->order_by('sp_menit_awal', 'DESC')->get_all_sanksipotonganmasuk();
		$res_gakmasuk 		= $this->report->where(array('abs_tanggal >=' => $strtotime_tanggal_awal, 'abs_tanggal <=' => $strtotime_tanggal_akhir))->get_all_gakmasuk();
		$res_gakmasukmesin 	= $this->report->where(array('abs_tanggal >=' => $strtotime_tanggal_awal, 'abs_tanggal <=' => $strtotime_tanggal_akhir))->get_all_gakmasukmesin();
		$res_masuk 			= $this->report->where(array('nDateTime >=' => $strtotime_tanggal_awal, 'nDateTime <=' => $strtotime_tanggal_akhir))->get_all_masuk();
		
		$this->_data['potongan'] 	= array();
		$this->_data['potongan_2'] 	= array();

		$history = array();
		
		foreach ($res_masuk as $val) {
			$history[$val['nDateTime']][$val['id_karyawan']] = 1;

			if(!empty($res_gakmasuk[$val['id_karyawan']][$val['nDateTime']])) continue;
			if(!empty($res_gakmasukmesin[$val['id_karyawan']][$val['nDateTime']]['MT'])) $val['nLateInTime'] = 0;
			if(!empty($res_gakmasukmesin[$val['id_karyawan']][$val['nDateTime']]['PC'])) $val['nEarlyOutTime'] = 0;

			if(empty($val['nLateInTime']) AND empty($val['nEarlyOutTime'])) continue;

			if(empty($this->_data['potongan'][$val['id_karyawan']])) {
				$this->_data['potongan'][$val['id_karyawan']] = $this->get_potongan_absensi($val, $res_potongan_masuk);
			} else {
				$this->_data['potongan'][$val['id_karyawan']] += $this->get_potongan_absensi($val, $res_potongan_masuk);
			}

			if($val['nLateInTime'] > 0) {
				foreach ($res_potongan_masuk['MT'][0] as $value) {
					if($val['nLateInTime'] >= $value['sp_menit_awal']) {
						$kode_potongan = $value['id_sanksi_potongan'];
						break;
					}
				}

				if(empty($this->_data['potongan_2'][$val['id_karyawan']][$kode_potongan])) {
					$this->_data['potongan_2'][$val['id_karyawan']][$kode_potongan] = $this->get_potongan_latetime($val, $res_potongan_masuk);
				} else {
					$this->_data['potongan_2'][$val['id_karyawan']][$kode_potongan] += $this->get_potongan_latetime($val, $res_potongan_masuk);
				}
			}

			if($val['nEarlyOutTime'] > 0) {
				foreach ($res_potongan_masuk['PC'][0] as $value) {
					if($val['nEarlyOutTime'] >= $value['sp_menit_awal']) {
						$kode_potongan = $value['id_sanksi_potongan'];
						break;
					}
				}

				if(empty($this->_data['potongan_2'][$val['id_karyawan']][$kode_potongan])) {
					$this->_data['potongan_2'][$val['id_karyawan']][$kode_potongan] = $this->get_potongan_earlytime($val, $res_potongan_masuk);
				} else {
					$this->_data['potongan_2'][$val['id_karyawan']][$kode_potongan] += $this->get_potongan_earlytime($val, $res_potongan_masuk);
				}
			}
		}

		//hitung potongan karyawan yg gak masuk, yang beralasan kecuali karyawan masuk terlambat n pulang cepat
		foreach ($res_gakmasuk as $vId) {
			foreach ($vId as $val) {
				foreach ($val as $vAkhir) {
					$history[$vAkhir['abs_tanggal']][$vAkhir['id_karyawan']] = 1;

					if(empty($this->_data['potongan'][$vAkhir['id_karyawan']])) {
						$this->_data['potongan'][$vAkhir['id_karyawan']] = round(($vAkhir['tunjangan'] / 100) * $res_potongan[$vAkhir['jp_kode']][$vAkhir['id_sanksi_potongan']]['persentase']);
					} else {
						$this->_data['potongan'][$vAkhir['id_karyawan']] += round(($vAkhir['tunjangan'] / 100) * $res_potongan[$vAkhir['jp_kode']][$vAkhir['id_sanksi_potongan']]['persentase']);
					}

					if(empty($this->_data['potongan_2'][$vAkhir['id_karyawan']][$vAkhir['id_sanksi_potongan']])) {
						$this->_data['potongan_2'][$vAkhir['id_karyawan']][$vAkhir['id_sanksi_potongan']] = round(($vAkhir['tunjangan'] / 100) * $res_potongan[$vAkhir['jp_kode']][$vAkhir['id_sanksi_potongan']]['persentase']);
					} else {
						$this->_data['potongan_2'][$vAkhir['id_karyawan']][$vAkhir['id_sanksi_potongan']] += round(($vAkhir['tunjangan'] / 100) * $res_potongan[$vAkhir['jp_kode']][$vAkhir['id_sanksi_potongan']]['persentase']);
					}
				}
			}
		}

		//hitung potongan karyawan yg gak masuk hanya karyawan masuk terlambat n pulang cepat
		foreach ($res_gakmasukmesin as $vId) {
			foreach ($vId as $vax) {
				foreach ($vax as $val) {
					foreach ($val as $vAkhir) {
						$history[$vAkhir['abs_tanggal']][$vAkhir['id_karyawan']] = 1;

						if(empty($this->_data['potongan'][$vAkhir['id_karyawan']])) {
							$this->_data['potongan'][$vAkhir['id_karyawan']] = round(($vAkhir['tunjangan'] / 100) * $res_potongan[$vAkhir['jp_kode']][$vAkhir['id_sanksi_potongan']]['persentase']);
						} else {
							$this->_data['potongan'][$vAkhir['id_karyawan']] += round(($vAkhir['tunjangan'] / 100) * $res_potongan[$vAkhir['jp_kode']][$vAkhir['id_sanksi_potongan']]['persentase']);
						}

						if(empty($this->_data['potongan_2'][$vAkhir['id_karyawan']][$vAkhir['id_sanksi_potongan']])) {
							$this->_data['potongan_2'][$vAkhir['id_karyawan']][$vAkhir['id_sanksi_potongan']] = round(($vAkhir['tunjangan'] / 100) * $res_potongan[$vAkhir['jp_kode']][$vAkhir['id_sanksi_potongan']]['persentase']);
						} else {
							$this->_data['potongan_2'][$vAkhir['id_karyawan']][$vAkhir['id_sanksi_potongan']] += round(($vAkhir['tunjangan'] / 100) * $res_potongan[$vAkhir['jp_kode']][$vAkhir['id_sanksi_potongan']]['persentase']);
						}
					}
				}
			}
		}

		//hitung potongan karyawan yg gak masuk yang gak beralasan
		if(!empty($history)) {
			foreach ($this->_data['result_karyawan'] as $key => $val) {
				foreach ($history as $kHistory => $vHistory) {
					if(!empty($history[$kHistory][$val['id_karyawan']])) continue;

					if(empty($this->_data['potongan'][$val['id_karyawan']])) {
						$this->_data['potongan'][$val['id_karyawan']] = round(($val['tunjangan'] / 100) * $res_potongan['TM'][1]['persentase']);
					} else {
						$this->_data['potongan'][$val['id_karyawan']] += round(($val['tunjangan'] / 100) * $res_potongan['TM'][1]['persentase']);
					}

					if(empty($this->_data['potongan_2'][$val['id_karyawan']][1])) {
						$this->_data['potongan_2'][$val['id_karyawan']][1] = round(($val['tunjangan'] / 100) * $res_potongan['TM'][1]['persentase']);
					} else {
						$this->_data['potongan_2'][$val['id_karyawan']][1] += round(($val['tunjangan'] / 100) * $res_potongan['TM'][1]['persentase']);
					}
				}
			}
		}
	}

	private function get_potongan_absensi($val, $res_potongan_masuk) {
		$potongan 	= 0;
		if($val['nLateInTime'] > 0) {
			foreach ($res_potongan_masuk['MT'][0] as $value) {
				if($val['nLateInTime'] >= $value['sp_menit_awal']) {
					$persentase = $value['persentase'];
					break;
				}
			}
			$potongan += round(($val['tunjangan'] / 100) * $persentase);
		}
		if($val['nEarlyOutTime'] > 0) {
			foreach ($res_potongan_masuk['PC'][0] as $value) {
				if($val['nEarlyOutTime'] >= $value['sp_menit_awal']) {
					$persentase = $value['persentase'];
					break;
				}
			}
			$potongan += round(($val['tunjangan'] / 100) * $persentase);
		}
		return $potongan;
	}

	private function get_potongan_latetime($val, $res_potongan_masuk) {
		$potongan 	= 0;
		if($val['nLateInTime'] > 0) {
			foreach ($res_potongan_masuk['MT'][0] as $value) {
				if($val['nLateInTime'] >= $value['sp_menit_awal']) {
					$persentase = $value['persentase'];
					break;
				}
			}
			$potongan += round(($val['tunjangan'] / 100) * $persentase);
		}
		return $potongan;
	}

	private function get_potongan_earlytime($val, $res_potongan_masuk) {
		$potongan 	= 0;
		if($val['nEarlyOutTime'] > 0) {
			foreach ($res_potongan_masuk['PC'][0] as $value) {
				if($val['nEarlyOutTime'] >= $value['sp_menit_awal']) {
					$persentase = $value['persentase'];
					break;
				}
			}
			$potongan += round(($val['tunjangan'] / 100) * $persentase);
		}
		return $potongan;
	}

	function do_print() {
		$this->do_submit();

		$this->template->load('template_print/main_landscape', 'print', $this->_data);
	}
}

?>