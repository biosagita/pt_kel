<div class="row page-header">
    <h3>Report Pot Grade</h3>
</div>

<div class="row">
    <?php if(isset($error)) : ?>
        <div class="alert alert-danger">
            <?php echo $error; ?>
        </div>
    <?php endif; ?>
    <form class="form-inline" role="form" action="<?php echo site_url('report/rekap-pot-grade'); ?>">
        <div class="form-group">
            <label for="txt_tanggal_awal">Tanggal Awal:</label>
            <input class="datepicker form-control" id="txt_tanggal_awal" name="txt_tanggal_awal" value="<?php echo (!empty($txt_tanggal_awal) ? $txt_tanggal_awal : ''); ?>">
        </div>
        <div class="form-group">
            <label for="txt_tanggal_akhir">Tanggal Akhir:</label>
            <input class="datepicker form-control" id="txt_tanggal_akhir" name="txt_tanggal_akhir" value="<?php echo (!empty($txt_tanggal_akhir) ? $txt_tanggal_akhir : ''); ?>">
        </div>
        <button type="submit" class="btn btn-default">Submit</button>
        <?php if(!empty($periode)): ?>
        <a href="<?php echo site_url('report/rekap-pot-grade/export?txt_tanggal_awal=' . $txt_tanggal_awal . '&txt_tanggal_akhir=' . $txt_tanggal_akhir); ?>" class="btn btn-success"><span class="glyphicon glyphicon-star" aria-hidden="true"></span> Export Excel</a> <a target="_blank" href="<?php echo site_url('report/rekap-pot-grade/print?txt_tanggal_awal=' . $txt_tanggal_awal . '&txt_tanggal_akhir=' . $txt_tanggal_akhir); ?>" class="btn btn-primary"><span class="glyphicon glyphicon-star" aria-hidden="true"></span> Print</a>
        <?php endif; ?>
    </form>
</div>

<?php if(!empty($periode)): ?>
<div class="row report">
    <p>REKAP POTONGAN ABSENSI<br />UNTUK TANGGAL : <?php echo $periode; ?></p>
    <?php foreach($result_grade as $valGrade) : ?>
    <?php if(!empty($result[$valGrade['kelas_grade']])) : ?>
    <p class="grade">GRADE <?php echo $valGrade['kelas_grade']; ?></p>
    <div class="table-responsive">
        <table class="table table-striped table-bordered table-condensed">
            <thead class="gray">
                <tr>
                    <th rowspan="5">NO.</th>
                    <th rowspan="5">NAMA / NIP</th>
                    <th colspan="<?php echo (count($result_potongan_masuk_1) + count($result_potongan_masuk_2)); ?>">KETERANGAN ABSEN</th>
                    <?php foreach($result_potongan_gakmasuk as $val) : ?>
                    <th rowspan="3"><?php echo $val['sp_nama']; ?></th>
                    <?php endforeach; ?>
                    <th rowspan="5">TOTAL POTONGAN</th>
                    <th rowspan="2">TOTAL TERIMA TUNKER</th>
                </tr>
                <tr>
                    <?php foreach($result_potongan_masuk_1 as $val) : ?>
                    <th rowspan="2"><?php echo $val['sp_nama']; ?></th>
                    <?php endforeach; ?>
                    <th colspan="4">TERLAMBAT MASUK KERJA TANPA IZIN/ALASAN YANG SAH</th>
                    <th colspan="4">TERLAMBAT MASUK KERJA DENGAN IZIN/ALASAN YANG SAH</th>
                    <th colspan="4">PULANG LEBIH AWAL TANPA IZIN/ALASAN YANG SAH</th>
                    <th colspan="4">PULANG LEBIH AWAL DENGAN IZIN/ALASAN YANG SAH</th>
                </tr>
                <tr>
                    <?php foreach($result_potongan_masuk_2 as $val) : ?>
                    <th><div style="width: 60px;"><?php echo ($val['sp_nama'] . ' (' . (!empty($val['sp_menit_akhir']) ? ('Menit ' . $val['sp_menit_awal'] . '-' . $val['sp_menit_akhir']) : ('> ' . $val['sp_menit_awal'])) . ')'); ?></div></th>
                    <?php endforeach; ?>
                    <th rowspan="3"><?php echo number_format($valGrade['tunjangan'], 0, ',', '.'); ?></th>
                </tr>
                <tr>
                    <?php foreach($result_potongan_masuk_1 as $val) : ?>
                    <th><?php echo $val['persentase']; ?> %</th>
                    <?php endforeach; ?>
                    <?php foreach($result_potongan_masuk_2 as $val) : ?>
                    <th><?php echo $val['persentase']; ?> %</th>
                    <?php endforeach; ?>
                    <?php foreach($result_potongan_gakmasuk as $val) : ?>
                    <th><?php echo $val['persentase']; ?> %</th>
                    <?php endforeach; ?>
                </tr>
                <tr>
                    <?php foreach($result_potongan_masuk_1 as $val) : ?>
                    <th><?php echo number_format(round(($valGrade['tunjangan'] / 100) * $val['persentase']), 0, ',', '.'); ?></th>
                    <?php endforeach; ?>
                    <?php foreach($result_potongan_masuk_2 as $val) : ?>
                    <th><?php echo number_format(round(($valGrade['tunjangan'] / 100) * $val['persentase']), 0, ',', '.'); ?></th>
                    <?php endforeach; ?>
                    <?php foreach($result_potongan_gakmasuk as $val) : ?>
                    <th><?php echo number_format(round(($valGrade['tunjangan'] / 100) * $val['persentase']), 0, ',', '.'); ?></th>
                    <?php endforeach; ?>
                </tr>
                <tr>
                    <th>1</th>
                    <th>2</th>
                    <?php $cnt = 3; foreach($result_potongan_masuk_1 as $val) : ?>
                    <th><?php echo $cnt; ?></th>
                    <?php $cnt++; endforeach; ?>
                    <?php foreach($result_potongan_masuk_2 as $val) : ?>
                    <th><?php echo $cnt; ?></th>
                    <?php $cnt++; endforeach; ?>
                    <?php foreach($result_potongan_gakmasuk as $val) : ?>
                    <th><?php echo $cnt; ?></th>
                    <?php $cnt++; endforeach; ?>
                    <th><?php echo ($cnt); ?></th>
                    <th><?php echo (++$cnt); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php 
                    $cnt = 0;
                    $total_potongan = 0;
                    $total_terima = 0;
                    $jumlah_potongan = array();
                ?>
                <?php foreach($result[$valGrade['kelas_grade']] as $keyKaryawan => $valKaryawan) : ?>
                <tr>
                    <td><?php echo ($cnt+1); ?></td>
                    <td><div style="text-align:left;width: 200px;"><?php echo $valKaryawan['nama_lengkap']; ?><br />NIP. <?php echo $valKaryawan['nip']; ?></div></td>
                    <?php foreach($result_potongan_masuk_1 as $val) : ?>
                    <?php 
                        $tmp_potongan = !empty($potongan_2[$valKaryawan['id_karyawan']][$val['id_sanksi_potongan']]) ? $potongan_2[$valKaryawan['id_karyawan']][$val['id_sanksi_potongan']] : 0;
                        if(empty($jumlah_potongan[$val['id_sanksi_potongan']])) {
                            $jumlah_potongan[$val['id_sanksi_potongan']] = $tmp_potongan;
                        } else {
                            $jumlah_potongan[$val['id_sanksi_potongan']] += $tmp_potongan;
                        }
                    ?>
                    <td><?php echo (!empty($tmp_potongan) ? number_format($tmp_potongan, 0, ',', '.') : '-'); ?></td>
                    <?php endforeach; ?>
                    <?php foreach($result_potongan_masuk_2 as $val) : ?>
                    <?php 
                        $tmp_potongan = !empty($potongan_2[$valKaryawan['id_karyawan']][$val['id_sanksi_potongan']]) ? $potongan_2[$valKaryawan['id_karyawan']][$val['id_sanksi_potongan']] : 0;
                        if(empty($jumlah_potongan[$val['id_sanksi_potongan']])) {
                            $jumlah_potongan[$val['id_sanksi_potongan']] = $tmp_potongan;
                        } else {
                            $jumlah_potongan[$val['id_sanksi_potongan']] += $tmp_potongan;
                        }
                    ?>
                    <td><?php echo (!empty($tmp_potongan) ? number_format($tmp_potongan, 0, ',', '.') : '-'); ?></td>
                    <?php endforeach; ?>
                    <?php foreach($result_potongan_gakmasuk as $val) : ?>
                    <?php 
                        $tmp_potongan = !empty($potongan_2[$valKaryawan['id_karyawan']][$val['id_sanksi_potongan']]) ? $potongan_2[$valKaryawan['id_karyawan']][$val['id_sanksi_potongan']] : 0;
                        if(empty($jumlah_potongan[$val['id_sanksi_potongan']])) {
                            $jumlah_potongan[$val['id_sanksi_potongan']] = $tmp_potongan;
                        } else {
                            $jumlah_potongan[$val['id_sanksi_potongan']] += $tmp_potongan;
                        }
                    ?>
                    <td><?php echo (!empty($tmp_potongan) ? number_format($tmp_potongan, 0, ',', '.') : '-'); ?></td>
                    <?php endforeach; ?>
                    <td><?php echo (!empty($potongan[$valKaryawan['id_karyawan']]) ? number_format($potongan[$valKaryawan['id_karyawan']], 0, ',', '.') : '-'); ?></td>
                    <?php $jumlah_terima = $valKaryawan['tunjangan'] - $potongan[$valKaryawan['id_karyawan']]; ?>
                    <td><?php echo (!empty($jumlah_terima) ? number_format($jumlah_terima, 0, ',', '.') : '-'); ?></td>
                    <?php
                        $total_potongan += $potongan[$valKaryawan['id_karyawan']];
                        $total_terima += $jumlah_terima;
                    ?>
                </tr>
                <?php $cnt++; ?>
                <?php endforeach; ?>
                <tr class="jumlah">
                    <td colspan="2">Jumlah</td>
                    <?php foreach($result_potongan_masuk_1 as $val) : ?>
                    <td><?php echo (!empty($jumlah_potongan[$val['id_sanksi_potongan']]) ? number_format($jumlah_potongan[$val['id_sanksi_potongan']], 0, ',', '.') : '-'); ?></td>
                    <?php endforeach; ?>
                    <?php foreach($result_potongan_masuk_2 as $val) : ?>
                    <td><?php echo (!empty($jumlah_potongan[$val['id_sanksi_potongan']]) ? number_format($jumlah_potongan[$val['id_sanksi_potongan']], 0, ',', '.') : '-'); ?></td>
                    <?php endforeach; ?>
                    <?php foreach($result_potongan_gakmasuk as $val) : ?>
                    <td><?php echo (!empty($jumlah_potongan[$val['id_sanksi_potongan']]) ? number_format($jumlah_potongan[$val['id_sanksi_potongan']], 0, ',', '.') : '-'); ?></td>
                    <?php endforeach; ?>
                    <td><?php echo (!empty($total_potongan) ? number_format($total_potongan, 0, ',', '.') : '-'); ?></td>
                    <td><?php echo (!empty($total_terima) ? number_format($total_terima, 0, ',', '.') : '-'); ?></td>
                </tr>
            </tbody>
        </table>
    </div>
    <hr />
    <?php endif; ?>
    <?php endforeach; ?>
</div>
<?php endif; ?>