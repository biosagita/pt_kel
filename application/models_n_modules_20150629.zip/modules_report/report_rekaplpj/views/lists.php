<style type="text/css">
    @media (min-width: 768px) {
        .form-inline .form-control{width: 100px;}
    }
</style>

<div class="row page-header">
    <h3>Report Rekap LPJ</h3>
</div>

<div class="row">
    <?php if(isset($error)) : ?>
        <div class="alert alert-danger">
            <?php echo $error; ?>
        </div>
    <?php endif; ?>
    <form class="form-inline" role="form" action="<?php echo site_url('report/rekap-lpj'); ?>">
        <div class="form-group">
            <label for="txt_saldo_awal">Saldo:</label>
            <input placeholder="Saldo Awal" class="form-control" id="txt_saldo_awal" name="txt_saldo_awal" value="<?php echo (!empty($txt_saldo_awal) ? $txt_saldo_awal : ''); ?>">
        </div>
        <div class="form-group">
            <label for="txt_transfer_setjen">Transfer:</label>
            <input placeholder="Transfer Setjen" class="form-control" id="txt_transfer_setjen" name="txt_transfer_setjen" value="<?php echo (!empty($txt_transfer_setjen) ? $txt_transfer_setjen : ''); ?>">
        </div>
        <div class="form-group">
            <label for="txt_tanggal_awal">Tanggal Awal:</label>
            <input class="datepicker form-control" id="txt_tanggal_awal" name="txt_tanggal_awal" value="<?php echo (!empty($txt_tanggal_awal) ? $txt_tanggal_awal : ''); ?>">
        </div>
        <div class="form-group">
            <label for="txt_tanggal_akhir">Tanggal Akhir:</label>
            <input class="datepicker form-control" id="txt_tanggal_akhir" name="txt_tanggal_akhir" value="<?php echo (!empty($txt_tanggal_akhir) ? $txt_tanggal_akhir : ''); ?>">
        </div>
        <button type="submit" class="btn btn-default">Submit</button>
        <?php if(!empty($periode)): ?>
        <a href="<?php echo site_url('report/rekap-lpj/export?txt_tanggal_awal=' . $txt_tanggal_awal . '&txt_tanggal_akhir=' . $txt_tanggal_akhir . '&txt_saldo_awal=' . $txt_saldo_awal . '&txt_transfer_setjen=' . $txt_transfer_setjen); ?>" class="btn btn-success"><span class="glyphicon glyphicon-star" aria-hidden="true"></span> Export Excel</a> <a target="_blank" href="<?php echo site_url('report/rekap-lpj/print?txt_tanggal_awal=' . $txt_tanggal_awal . '&txt_tanggal_akhir=' . $txt_tanggal_akhir . '&txt_saldo_awal=' . $txt_saldo_awal . '&txt_transfer_setjen=' . $txt_transfer_setjen); ?>" class="btn btn-primary"><span class="glyphicon glyphicon-star" aria-hidden="true"></span> Print</a>
        <?php endif; ?>
    </form>
</div>

<?php if(!empty($periode)): ?>
<div class="row report">
    <p>REKAPITULASI LAPORAN PERTANGGUNG JAWABAN TUNJANGAN KINERJA (REVISI)<br />KANTOR IMIGRASI KELAS I JAKARTA UTARA<br />UNTUK TANGGAL : <?php echo $periode; ?></p>
    <div class="table-responsive">
        <table class="table table-striped table-bordered table-condensed">
            <thead class="gray">
                <tr>
                    <th rowspan="2">NO.</th>
                    <th rowspan="2">NAMA KANTOR/UPT</th>
                    <th rowspan="2">SALDO AWAL</th>
                    <th rowspan="2">TRANSFER SETJEN</th>
                    <th rowspan="2">TOTAL KEBUTUHAN</th>
                    <th colspan="2">REALISASI</th>
                    <th rowspan="2">BRUTO</th>
                    <th colspan="2">POTONGAN</th>
                    <th rowspan="2">NETTO</th>
                    <th rowspan="2">SISA DANA/SALDO AKHIR</th>
                </tr>
                <tr>
                    <th>TUNJANGAN KINERJA</th>
                    <th>PPh 21</th>
                    <th>PPh 21</th>
                    <th>FAKTOR PENGURANG</th>
                </tr>
                <tr>
                    <th>1</th>
                    <th>2</th>
                    <th>3</th>
                    <th>4</th>
                    <th>5=(3+4)</th>
                    <th>6</th>
                    <th>7</th>
                    <th>8=(6+7)</th>
                    <th>9</th>
                    <th>10</th>
                    <th>11=(8-9-10)</th>
                    <th>12=(5-11)</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>1</td>
                    <td><div style="width:200px;">KANTOR IMIGRASI KELAS I JAKARTA UTARA</div></td>
                    <td><div style="text-align:right;"><?php echo (!empty($txt_saldo_awal) ? number_format($txt_saldo_awal, 0 , ',', '.') : '-'); ?></div></td>
                    <td><div style="text-align:right;"><?php echo (!empty($txt_transfer_setjen) ? number_format($txt_transfer_setjen, 0 , ',', '.') : '-'); ?></div></td>
                    <td><div style="text-align:right;"><?php echo (!empty($total_kebutuhan) ? number_format($total_kebutuhan, 0 , ',', '.') : '-'); ?></div></td>
                    <td><div style="text-align:right;"><?php echo (!empty($total_tunjangan) ? number_format($total_tunjangan, 0 , ',', '.') : '-'); ?></div></td>
                    <td><div style="text-align:right;"><?php echo (!empty($pajak) ? number_format($pajak, 0 , ',', '.') : '-'); ?></div></td>
                    <td><div style="text-align:right;"><?php echo (!empty($bruto) ? number_format($bruto, 0 , ',', '.') : '-'); ?></div></td>
                    <td><div style="text-align:right;"><?php echo (!empty($pajak) ? number_format($pajak, 0 , ',', '.') : '-'); ?></div></td>
                    <td><div style="text-align:right;"><?php echo (!empty($total_potongan) ? number_format($total_potongan, 0 , ',', '.') : '-'); ?></div></td>
                    <td><div style="text-align:right;"><?php echo (!empty($netto) ? number_format($netto, 0 , ',', '.') : '-'); ?></div></td>
                    <td><div style="text-align:right;"><?php echo (!empty($sisa_dana) ? number_format($sisa_dana, 0 , ',', '.') : '-'); ?></div></td>
                </tr>
                <tr class="jumlah">
                    <td colspan="2">Jumlah</td>
                    <td><div style="text-align:right;"><?php echo (!empty($txt_saldo_awal) ? number_format($txt_saldo_awal, 0 , ',', '.') : '-'); ?></div></td>
                    <td><div style="text-align:right;"><?php echo (!empty($txt_transfer_setjen) ? number_format($txt_transfer_setjen, 0 , ',', '.') : '-'); ?></div></td>
                    <td><div style="text-align:right;"><?php echo (!empty($total_kebutuhan) ? number_format($total_kebutuhan, 0 , ',', '.') : '-'); ?></div></td>
                    <td><div style="text-align:right;"><?php echo (!empty($total_tunjangan) ? number_format($total_tunjangan, 0 , ',', '.') : '-'); ?></div></td>
                    <td><div style="text-align:right;"><?php echo (!empty($pajak) ? number_format($pajak, 0 , ',', '.') : '-'); ?></div></td>
                    <td><div style="text-align:right;"><?php echo (!empty($bruto) ? number_format($bruto, 0 , ',', '.') : '-'); ?></div></td>
                    <td><div style="text-align:right;"><?php echo (!empty($pajak) ? number_format($pajak, 0 , ',', '.') : '-'); ?></div></td>
                    <td><div style="text-align:right;"><?php echo (!empty($total_potongan) ? number_format($total_potongan, 0 , ',', '.') : '-'); ?></div></td>
                    <td><div style="text-align:right;"><?php echo (!empty($netto) ? number_format($netto, 0 , ',', '.') : '-'); ?></div></td>
                    <td><div style="text-align:right;"><?php echo (!empty($sisa_dana) ? number_format($sisa_dana, 0 , ',', '.') : '-'); ?></div></td>
                </tr>
            </tbody>
        </table>
    </div>
</div>
<?php endif; ?>