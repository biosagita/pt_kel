<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Report_model extends CI_Model {
	
	function where($where = '') {
		if($where != '') $this->db->where($where);
		return $this;
	}
	
	function set_limit($limit, $start = 0) {
    	$this->db->limit($limit, $start);
        return $this;
    }
	
	function order_by($field, $direction = 'asc') {
		$this->db->order_by($field, $direction);
		return $this;
	}
	
	function like($field, $keyword, $pattern = 'both') {
		$this->db->like($field, $keyword, $pattern);
		return $this;
	}
	
	function or_like($field, $keyword = '', $pattern = 'both'){
		if($keyword != '') $this->db->or_like($field, $keyword, $pattern);
		else  $this->db->or_like($field);
		return $this;
	}
	
	function group_by($group_by = ''){
		$this->db->group_by($group_by);
		return $this;
	}
	
	/* ---------------------------------------- All About Report ------------------------- */

	function get_all_karyawan(){
		$this->db->select('id_user, id_karyawan, kary_id_jabatan, nama_jabatan, kary_id_golongan, nama_golongan, kary_id_grade, kelas_grade, tunjangan, sUserName, norek, nip, is_cpns, nama_lengkap');
		$this->db->from('TB_AA_KARYAWAN');
		$this->db->join('TB_USER', 'id_user = nUserIdn');
		$this->db->join('TB_AA_JABATAN', 'kary_id_jabatan = id_jabatan', 'left');
		$this->db->join('TB_AA_GRADE', 'kary_id_grade = id_grade', 'left');
		$this->db->join('TB_AA_GOLONGAN', 'kary_id_golongan = id_golongan', 'left');

		return $this->db->get()->result_array();
	}

	function get_all_karyawan_grade(){
		$this->db->select('id_user, id_karyawan, kary_id_jabatan, nama_jabatan, kary_id_golongan, nama_golongan, kary_id_grade, kelas_grade, tunjangan, sUserName, norek, nip, is_cpns, nama_lengkap');
		$this->db->from('TB_AA_KARYAWAN');
		$this->db->join('TB_USER', 'id_user = nUserIdn');
		$this->db->join('TB_AA_JABATAN', 'kary_id_jabatan = id_jabatan', 'left');
		$this->db->join('TB_AA_GRADE', 'kary_id_grade = id_grade', 'left');
		$this->db->join('TB_AA_GOLONGAN', 'kary_id_golongan = id_golongan', 'left');

		$res = $this->db->get()->result_array();

		$data = array();
		foreach ($res as $val) {
			$data[$val['kelas_grade']][$val['id_karyawan']] = $val;
		}
		return $data;
	}

	function get_all_masuk(){
		$this->db->select('id_user, id_karyawan, nLateInTime, nEarlyOutTime, tunjangan, kelas_grade, nDateTime');
		$this->db->from('TB_AA_KARYAWAN');
		$this->db->join('TB_USER', 'id_user = nUserIdn');
		$this->db->join('TB_AA_GRADE', 'kary_id_grade = id_grade');
		$this->db->join('TB_TA_RESULT', 'TB_USER.nUserIdn = TB_TA_RESULT.nUserIdn', 'left');

		$res = $this->db->get()->result_array();
		//echo $this->db->last_query();
		return $res;
	}

	function get_all_potongan(){
		$res = $this->db->get('TB_AA_POTONGAN')->result_array();
		foreach ($res as $val) {
			$data[$val['kode_potongan']] = $val;
		}
		return $data;
	}

	function get_all_potongan_masuk_1(){
		$this->db->select('jp_kode, sp_persentase as persentase, id_jenis_potongan, id_sanksi_potongan, sp_izin_status, sp_menit_awal, sp_menit_akhir, sp_nama');
		$this->db->from('TB_AA_JENIS_POTONGAN');
		$this->db->join('TB_AA_SANKSI_POTONGAN', 'id_jenis_potongan = sp_id_jenis_potongan');
		$this->db->where_in('jp_kode', array('TM'));

		$res = $this->db->get()->result_array();
		foreach ($res as $val) {
			$data[$val['id_sanksi_potongan']] = $val;
		}
		return $data;
	}

	function get_all_potongan_masuk_2(){
		$this->db->select('jp_kode, sp_persentase as persentase, id_jenis_potongan, id_sanksi_potongan, sp_izin_status, sp_menit_awal, sp_menit_akhir, sp_nama');
		$this->db->from('TB_AA_JENIS_POTONGAN');
		$this->db->join('TB_AA_SANKSI_POTONGAN', 'id_jenis_potongan = sp_id_jenis_potongan');
		$this->db->where_in('jp_kode', array('MT', 'PC'));
		$this->db->order_by('id_jenis_potongan asc, id_sanksi_potongan asc');

		$res = $this->db->get()->result_array();
		foreach ($res as $val) {
			$data[$val['id_sanksi_potongan']] = $val;
		}
		return $data;
	}

	function get_all_potongan_gakmasuk(){
		$this->db->select('jp_kode, sp_persentase as persentase, id_jenis_potongan, id_sanksi_potongan, sp_izin_status, sp_menit_awal, sp_menit_akhir, sp_nama');
		$this->db->from('TB_AA_JENIS_POTONGAN');
		$this->db->join('TB_AA_SANKSI_POTONGAN', 'id_jenis_potongan = sp_id_jenis_potongan');
		$this->db->where_not_in('jp_kode', array('TM', 'MT', 'PC'));

		$res = $this->db->get()->result_array();
		foreach ($res as $val) {
			$data[$val['id_sanksi_potongan']] = $val;
		}
		return $data;
	}

	//sanksi potongan
	function get_all_sanksipotongan(){
		$this->db->select('jp_kode, sp_persentase as persentase, id_jenis_potongan, id_sanksi_potongan, sp_izin_status, sp_menit_awal, sp_menit_akhir');
		$this->db->from('TB_AA_JENIS_POTONGAN');
		$this->db->join('TB_AA_SANKSI_POTONGAN', 'id_jenis_potongan = sp_id_jenis_potongan');

		$res = $this->db->get()->result_array();
		foreach ($res as $val) {
			$data[$val['jp_kode']][$val['id_sanksi_potongan']] = $val;
		}
		return $data;
	}

	function get_all_sanksipotonganmasuk(){
		$this->db->select('jp_kode, sp_persentase as persentase, id_jenis_potongan, id_sanksi_potongan, sp_izin_status, sp_menit_awal, sp_menit_akhir');
		$this->db->from('TB_AA_JENIS_POTONGAN');
		$this->db->join('TB_AA_SANKSI_POTONGAN', 'id_jenis_potongan = sp_id_jenis_potongan');
		$this->db->where_in('jp_kode', array('MT', 'PC'));

		$res = $this->db->get()->result_array();
		foreach ($res as $val) {
			$data[$val['jp_kode']][$val['sp_izin_status']][$val['id_sanksi_potongan']] = $val;
		}
		return $data;
	}

	function get_all_gakmasuk(){
		$data = array();
		$this->db->select('id_karyawan, tunjangan, kelas_grade, jp_kode, id_absen, abs_tanggal, sp_persentase as persentase, id_jenis_potongan, id_sanksi_potongan');
		$this->db->from('TB_AA_KARYAWAN');
		$this->db->join('TB_USER', 'id_user = nUserIdn');
		$this->db->join('TB_AA_ABSEN', 'id_karyawan = abs_id_karyawan');
		$this->db->join('TB_AA_SANKSI_POTONGAN', 'id_sanksi_potongan = abs_id_sanksi_potongan');
		$this->db->join('TB_AA_JENIS_POTONGAN', 'id_jenis_potongan = sp_id_jenis_potongan');
		$this->db->join('TB_AA_GRADE', 'kary_id_grade = id_grade');
		$this->db->where_not_in('jp_kode', array('MT', 'PC'));

		$res = $this->db->get()->result_array();

		foreach ($res as $val) {
			$data[$val['id_karyawan']][$val['abs_tanggal']][$val['id_absen']] = $val;
		}
		return $data;
	}

	function get_all_gakmasukmesin(){
		$data = array();
		$this->db->select('id_karyawan, tunjangan, kelas_grade, jp_kode, id_absen, abs_tanggal, sp_persentase as persentase, id_jenis_potongan, id_sanksi_potongan');
		$this->db->from('TB_AA_KARYAWAN');
		$this->db->join('TB_USER', 'id_user = nUserIdn');
		$this->db->join('TB_AA_ABSEN', 'id_karyawan = abs_id_karyawan');
		$this->db->join('TB_AA_SANKSI_POTONGAN', 'id_sanksi_potongan = abs_id_sanksi_potongan');
		$this->db->join('TB_AA_JENIS_POTONGAN', 'id_jenis_potongan = sp_id_jenis_potongan');
		$this->db->join('TB_AA_GRADE', 'kary_id_grade = id_grade');
		$this->db->where_in('jp_kode', array('MT', 'PC'));

		$res = $this->db->get()->result_array();

		foreach ($res as $val) {
			$data[$val['id_karyawan']][$val['abs_tanggal']][$val['jp_kode']][$val['id_absen']] = $val;
		}
		return $data;
	}

	function get_all_grade(){
		return $this->db->get('TB_AA_GRADE')->result_array();
	}
	
}

?>