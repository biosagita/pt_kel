<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Crud_model extends CI_Model {
	
	function where($where = '') {
		if($where != '') $this->db->where($where);
		return $this;
	}

	function where_in($fieldname = '', $where = '') {
		if($where != '' AND $fieldname != '') $this->db->where_in($fieldname, $where);
		return $this;
	}

	function where_not_in($fieldname = '', $where = '') {
		if($where != '' AND $fieldname != '') $this->db->where_not_in($fieldname, $where);
		return $this;
	}
	
	function set_limit($limit, $start = 0) {
    	$this->db->limit($limit, $start);
        return $this;
    }
	
	function order_by($field, $direction = 'asc') {
		$this->db->order_by($field, $direction);
		return $this;
	}
	
	function like($field, $keyword, $pattern = 'both') {
		$this->db->like($field, $keyword, $pattern);
		return $this;
	}
	
	function or_like($field, $keyword = '', $pattern = 'both'){
		if($keyword != '') $this->db->or_like($field, $keyword, $pattern);
		else  $this->db->or_like($field);
		return $this;
	}
	
	function group_by($group_by = ''){
		$this->db->group_by($group_by);
		return $this;
	}
	
	/* ---------------------------------------- All About Admin ------------------------- */

	//JABATAN
	function get_row_jabatan(){
		return $this->db->get('TB_AA_JABATAN')->row_array();
	}
	
	function get_all_jabatan(){
		return $this->db->get('TB_AA_JABATAN')->result_array();
	}
	
	function posts_jabatan($data){
		return $this->db->insert('TB_AA_JABATAN', $data);
	}
	
	function puts_jabatan($data){
		return $this->db->update('TB_AA_JABATAN', $data);
	}
	
	function delete_jabatan($data){
		return $this->db->delete('TB_AA_JABATAN', $data);
	}

	function get_option_jabatan() {
		$res = $this->get_all_jabatan();
		$data = array();
		foreach ($res as $key => $value) {
			$data[] = array(
				'name' 	=> $value['nama_jabatan'],
				'value' => $value['id_jabatan'],
			); 
		}
		return $data;
	}

	//Jenis Potongan
	function get_row_jenispotongan(){
		return $this->db->get('TB_AA_JENIS_POTONGAN')->row_array();
	}
	
	function get_all_jenispotongan(){
		return $this->db->get('TB_AA_JENIS_POTONGAN')->result_array();
	}
	
	function posts_jenispotongan($data){
		return $this->db->insert('TB_AA_JENIS_POTONGAN', $data);
	}
	
	function puts_jenispotongan($data){
		return $this->db->update('TB_AA_JENIS_POTONGAN', $data);
	}
	
	function delete_jenispotongan($data){
		return $this->db->delete('TB_AA_JENIS_POTONGAN', $data);
	}

	function get_option_jenispotongan() {
		$res = $this->get_all_jenispotongan();
		$data = array();
		foreach ($res as $key => $value) {
			$data[$value['jp_kode']] = array(
				'name' 	=> $value['jp_nama'],
				'value' => $value['id_jenis_potongan'],
			); 
		}
		return $data;
	}

	//POTONGAN
	function get_row_potongan(){
		return $this->db->get('TB_AA_POTONGAN')->row_array();
	}
	
	function get_all_potongan(){
		return $this->db->get('TB_AA_POTONGAN')->result_array();
	}
	
	function posts_potongan($data){
		return $this->db->insert('TB_AA_POTONGAN', $data);
	}
	
	function puts_potongan($data){
		return $this->db->update('TB_AA_POTONGAN', $data);
	}
	
	function delete_potongan($data){
		return $this->db->delete('TB_AA_POTONGAN', $data);
	}

	function get_option_potongan() {
		$res = $this->get_all_potongan();
		$data = array();
		foreach ($res as $key => $value) {
			$data[] = array(
				'name' 	=> $value['nama_potongan'],
				'value' => $value['id_potongan'],
			); 
		}
		return $data;
	}

	//GRADE
	function get_row_grade(){
		return $this->db->get('TB_AA_GRADE')->row_array();
	}
	
	function get_all_grade(){
		return $this->db->get('TB_AA_GRADE')->result_array();
	}
	
	function posts_grade($data){
		return $this->db->insert('TB_AA_GRADE', $data);
	}
	
	function puts_grade($data){
		return $this->db->update('TB_AA_GRADE', $data);
	}
	
	function delete_grade($data){
		return $this->db->delete('TB_AA_GRADE', $data);
	}

	function get_option_grade() {
		$res = $this->get_all_grade();
		$data = array();
		foreach ($res as $key => $value) {
			$data[] = array(
				'name' 	=> $value['kelas_grade'],
				'value' => $value['id_grade'],
			); 
		}
		return $data;
	}	

	//GOLONGAN
	function get_row_golongan(){
		return $this->db->get('TB_AA_GOLONGAN')->row_array();
	}
	
	function get_all_golongan(){
		return $this->db->get('TB_AA_GOLONGAN')->result_array();
	}
	
	function posts_golongan($data){
		return $this->db->insert('TB_AA_GOLONGAN', $data);
	}
	
	function puts_golongan($data){
		return $this->db->update('TB_AA_GOLONGAN', $data);
	}
	
	function delete_golongan($data){
		return $this->db->delete('TB_AA_GOLONGAN', $data);
	}

	function get_option_golongan() {
		$res = $this->get_all_golongan();
		$data = array();
		foreach ($res as $key => $value) {
			$data[] = array(
				'name' 	=> $value['nama_golongan'],
				'value' => $value['id_golongan'],
			); 
		}
		return $data;
	}

	//KARYAWAN
	function get_row_karyawan(){
		$this->db->select('id_user, id_karyawan, kary_id_jabatan, nama_jabatan, kary_id_golongan, nama_golongan, kary_id_grade, kelas_grade, tunjangan, sUserName, norek, nip, is_cpns, nama_lengkap');
		$this->db->from('TB_AA_KARYAWAN');
		$this->db->join('TB_USER', 'id_user = nUserIdn');
		$this->db->join('TB_AA_JABATAN', 'kary_id_jabatan = id_jabatan', 'left');
		$this->db->join('TB_AA_GRADE', 'kary_id_grade = id_grade', 'left');
		$this->db->join('TB_AA_GOLONGAN', 'kary_id_golongan = id_golongan', 'left');

		return $this->db->get()->row_array();
	}
	
	function get_all_karyawan(){
		$this->db->select('id_user, id_karyawan, kary_id_jabatan, nama_jabatan, kary_id_golongan, nama_golongan, kary_id_grade, kelas_grade, tunjangan, sUserName, norek, nip, is_cpns, nama_lengkap');
		$this->db->from('TB_AA_KARYAWAN');
		$this->db->join('TB_USER', 'id_user = nUserIdn');
		$this->db->join('TB_AA_JABATAN', 'kary_id_jabatan = id_jabatan', 'left');
		$this->db->join('TB_AA_GRADE', 'kary_id_grade = id_grade', 'left');
		$this->db->join('TB_AA_GOLONGAN', 'kary_id_golongan = id_golongan', 'left');

		return $this->db->get()->result_array();
	}
	
	function posts_karyawan($data){
		return $this->db->insert('TB_AA_KARYAWAN', $data);
	}
	
	function puts_karyawan($data){
		return $this->db->update('TB_AA_KARYAWAN', $data);
	}
	
	function delete_karyawan($data){
		return $this->db->delete('TB_AA_KARYAWAN', $data);
	}

	function get_option_karyawan() {
		$res = $this->get_all_karyawan();
		$data = array();
		foreach ($res as $key => $value) {
			$data[] = array(
				'name' 	=> ($value['sUserName'] . (!empty($value['nip']) ? ' (NIP. ' . $value['nip'] . ')' : '')),
				'value' => $value['id_karyawan'],
			); 
		}
		return $data;
	}

	//USER
	function get_all_user(){
		$this->db->select('nUserIdn, sUserName, nip');
		$this->db->from('TB_USER');
		$this->db->join('TB_AA_KARYAWAN', 'id_user = nUserIdn', 'left');

		return $this->db->get()->result_array();
	}
	
	function get_option_user() {
		$res = $this->get_all_user();
		$data = array();
		foreach ($res as $key => $value) {
			$data[] = array(
				'name' 	=> ($value['sUserName'] . (!empty($value['nip']) ? ' (NIP. ' . $value['nip'] . ')' : '')),
				'value' => $value['nUserIdn'],
			); 
		}
		return $data;
	}

	//GRADE
	function get_row_absen(){
		return $this->db->get('TB_AA_ABSEN')->row_array();
	}
	
	function get_all_absen(){
		$this->db->select('id_karyawan, sUserName, nama_potongan, abs_tanggal, abs_note, id_absen');
		$this->db->from('TB_AA_ABSEN');
		$this->db->join('TB_AA_KARYAWAN', 'id_karyawan = abs_id_karyawan');
		$this->db->join('TB_USER', 'id_user = nUserIdn');
		$this->db->join('TB_AA_POTONGAN', 'id_potongan = abs_id_sanksi_potongan');

		return $this->db->get()->result_array();
	}
	
	function posts_absen($data){
		return $this->db->insert('TB_AA_ABSEN', $data);
	}
	
	function puts_absen($data){
		return $this->db->update('TB_AA_ABSEN', $data);
	}
	
	function delete_absen($data){
		return $this->db->delete('TB_AA_ABSEN', $data);
	}

	//SANKSI POTONGAN
	function get_row_sanksipotongan(){
		return $this->db->get('TB_AA_SANKSI_POTONGAN')->row_array();
	}
	
	function get_all_sanksipotongan(){
		return $this->db->get('TB_AA_SANKSI_POTONGAN')->result_array();
	}
	
	function posts_sanksipotongan($data){
		return $this->db->insert('TB_AA_SANKSI_POTONGAN', $data);
	}
	
	function puts_sanksipotongan($data){
		return $this->db->update('TB_AA_SANKSI_POTONGAN', $data);
	}
	
	function delete_sanksipotongan($data){
		return $this->db->delete('TB_AA_SANKSI_POTONGAN', $data);
	}

	function get_option_sanksipotongan() {
		$res = $this->get_all_sanksipotongan();
		$data = array();
		foreach ($res as $key => $value) {
			$data[] = array(
				'name' 	=> $value['sp_nama'],
				'value' => $value['id_sanksi_potongan'],
			); 
		}
		return $data;
	}

	function get_row_result_absen() {
		$this->db->select('id_karyawan, nama_lengkap, sp_nama, jp_nama, abs_tanggal, abs_note, id_absen, id_sanksi_potongan, sp_izin_status, id_jenis_potongan, jp_kode');
		$this->db->from('TB_AA_KARYAWAN');
		$this->db->join('TB_AA_ABSEN', 'id_karyawan = abs_id_karyawan', 'left');
		$this->db->join('TB_AA_SANKSI_POTONGAN', 'id_sanksi_potongan = abs_id_sanksi_potongan', 'left');
		$this->db->join('TB_AA_JENIS_POTONGAN', 'id_jenis_potongan = sp_id_jenis_potongan', 'left');

		return $this->db->get()->row_array();
	}

	function get_all_result_absen() {
		$this->db->select('id_karyawan, nama_lengkap, sp_nama, jp_nama, abs_tanggal, abs_note, id_absen, id_sanksi_potongan, sp_izin_status, id_jenis_potongan, jp_kode');
		$this->db->from('TB_AA_ABSEN');
		$this->db->join('TB_AA_KARYAWAN', 'id_karyawan = abs_id_karyawan');
		$this->db->join('TB_AA_SANKSI_POTONGAN', 'id_sanksi_potongan = abs_id_sanksi_potongan');
		$this->db->join('TB_AA_JENIS_POTONGAN', 'id_jenis_potongan = sp_id_jenis_potongan');

		$res = $this->db->get()->result_array();

		$data = array();
		foreach ($res as $key => $value) {
			$data[$value['id_karyawan']][$value['abs_tanggal']] = $value;
		}
		return $data;
	}

	function get_all_result_absen_masuk() {
		$this->db->select('id_karyawan, nama_lengkap, sp_nama, jp_nama, abs_tanggal, abs_note, id_absen, id_sanksi_potongan, sp_izin_status, id_jenis_potongan, jp_kode');
		$this->db->from('TB_AA_ABSEN');
		$this->db->join('TB_AA_KARYAWAN', 'id_karyawan = abs_id_karyawan');
		$this->db->join('TB_AA_SANKSI_POTONGAN', 'id_sanksi_potongan = abs_id_sanksi_potongan');
		$this->db->join('TB_AA_JENIS_POTONGAN', 'id_jenis_potongan = sp_id_jenis_potongan');

		$res = $this->db->get()->result_array();

		$data = array();
		foreach ($res as $key => $value) {
			$data[$value['id_karyawan']][$value['abs_tanggal']][$value['jp_kode']] = $value;
		}
		return $data;
	}

	function get_all_result_karyawan() {
		$this->db->select('id_karyawan, nama_lengkap');
		$this->db->from('TB_AA_KARYAWAN');
		$this->db->join('TB_USER', 'id_user = nUserIdn');

		$res = $this->db->get()->result_array();

		$data = array();
		foreach ($res as $key => $value) {
			$data[$value['id_karyawan']] = $value;
		}
		return $data;
	}

	function get_all_result_mesin() {
		$this->db->select('id_karyawan, nLateInTime, nEarlyOutTime, nDateTime');
		$this->db->from('TB_AA_KARYAWAN');
		$this->db->join('TB_TA_RESULT', 'id_user = nUserIdn');

		$res = $this->db->get()->result_array();

		//echo $this->db->last_query(); exit();

		$data = array();
		foreach ($res as $key => $value) {
			$tgl = date('d-m-Y', $value['nDateTime']);
			$data[$value['id_karyawan']][$tgl] = $value;
		}
		return $data;
	}

	function get_row_mesin(){
		$this->db->select('id_karyawan, nLateInTime, nEarlyOutTime, nDateTime');
		$this->db->from('TB_AA_KARYAWAN');
		$this->db->join('TB_TA_RESULT', 'id_user = nUserIdn');

		return $this->db->get()->row_array();
	}

	function get_all_jenissanksipotongan(){
		$this->db->select('sp_nama, jp_nama, sp_menit_awal, sp_menit_akhir, id_sanksi_potongan');
		$this->db->from('TB_AA_JENIS_POTONGAN');
		$this->db->join('TB_AA_SANKSI_POTONGAN', 'id_jenis_potongan = sp_id_jenis_potongan');

		return $this->db->get()->result_array();
	}
}

?>