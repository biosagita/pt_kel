<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Absen extends MY_Admin {
	private $_template 			= 'template_admin/main';
	private $_module_controller = 'backend_absen/absen/';
	private $_table_name 		= 'TB_AA_ABSEN';
	private $_table_pk 			= 'id_absen';
	private $_model_crud 		= 'crud_model';

	private $_page_title 		= 'Antrian : Admin Absen';
	private $_page_content_info	= array(
		'title' => 'Data Admin Absen',
		'desc' 	=> 'List Absen',
	);

	function __construct(){
		parent::__construct();

		if(!$this->session->userdata('admin_id')) {
			redirect('backend_login/login');
			exit();
		}

		$this->load->model($this->_model_crud,'crudmodel');
	}

	private function get_show_column() {
		$column_list = array(
			array(
				'title_header_column' 	=> 'No.',
				'field_name' 			=> 'id_absen',
				'show_no_static' 		=> true,
				'no_order'				=> 0,
			),
			array(
				'title_header_column' 	=> 'Nama',
				'field_name' 			=> 'sUserName',
				'no_order'				=> 1,
			),
			array(
				'title_header_column' 	=> 'Absen',
				'field_name' 			=> 'nama_potongan',
				'no_order'				=> 2,
			),
			array(
				'title_header_column' 	=> 'Izin',
				'field_name' 			=> 'abs_tanggal',
				'no_order'				=> 3,
			),
			array(
				'title_header_column' 	=> 'Catatan',
				'field_name' 			=> 'abs_note',
				'no_order'				=> 4,
			),
			array(
				'title_header_column' 	=> 'Action',
				'field_name' 			=> 'id_absen',
				'result_format'			=> function( $d, $row ) {
			            return '<a onclick="doFormEdit('.$d.');return false;" href="#" class="btn btn-xs btn-success">EDIT <i class="glyph-icon icon-pencil-square-o"></i></a>';
			        },
			    'no_order'				=> 5,
			),
		);

		return $column_list;
	}
	
	function index() {
		$this->lists();
	}

	function lists() {
		$this->_data['ajax_lists'] 			= site_url($this->_module_controller . 'lists_ajax');
		$this->_data['ajax_form_add'] 		= site_url($this->_module_controller . 'add_ajax');
		$this->_data['ajax_form_edit'] 		= site_url($this->_module_controller . 'edit_ajax');
		$this->_data['ajax_action_delete'] 	= site_url($this->_module_controller . 'do_delete_ajax');

		$this->_data['column_list'] = $this->get_show_column();

		$this->_data['info_page'] = $this->_page_content_info;

		$this->_data['source_jenispotongan_masuk'] 		= $this->crudmodel->where_in('jp_kode', array('MT', 'PC'))->get_option_jenispotongan();
		$this->_data['source_jenispotongan_gakmasuk'] 	= $this->crudmodel->where_not_in('jp_kode', array('MT', 'PC'))->get_option_jenispotongan();

		$this->_data['result_absen'] 		= array();
		$this->_data['result_karyawan'] 	= array();
		$this->_data['result_mesin'] 		= array();
		$this->_data['result_absen_masuk'] 	= array();

		//echo date('Y-m-d H:i:s', 1435276800); exit();

		$this->_data['txt_tanggal'] = '';
		$this->_data['tanggal'] 	= '';
		if(!empty($_GET['txt_tanggal'])) {
			$this->_data['txt_tanggal']		= $_GET['txt_tanggal'];
			$tanggal_awal 	= $this->_data['tanggal'] = strtotime(($this->_data['txt_tanggal'] . ' 00:00:00'));
			$tanggal_akhir 	= $this->_data['tanggal'] = strtotime(($this->_data['txt_tanggal'] . ' 23:59:00'));
			$this->_data['result_absen'] 	= $this->crudmodel->where(array('abs_tanggal' => $tanggal))->get_all_result_absen();
			$this->_data['result_karyawan'] = $this->crudmodel->get_all_result_karyawan();
			$this->_data['result_mesin'] 	= $this->crudmodel->where(array('nDateTime >=' => $tanggal_awal, 'nDateTime <=' => $tanggal_akhir))->get_all_result_mesin();
			$this->_data['result_absen_masuk'] 	= $this->crudmodel->where(array('abs_tanggal' => $tanggal))->get_all_result_absen_masuk();
		}

		//using lib template
		$this->template->set('title', $this->_page_title);
		$this->template->set('assets', $this->_data['assets']);
		$this->template->load($this->_template, 'lists', $this->_data);
	}

	function page_content_ajax() {
		$this->_data['page_content_ajax'] 	= site_url($this->_module_controller . 'page_content_ajax');
		$this->_data['ajax_lists'] 			= site_url($this->_module_controller . 'lists_ajax');
		$this->_data['ajax_form_add'] 		= site_url($this->_module_controller . 'add_ajax');
		$this->_data['ajax_form_edit'] 		= site_url($this->_module_controller . 'edit_ajax');
		$this->_data['ajax_action_delete'] 	= site_url($this->_module_controller . 'do_delete_ajax');

		$this->_data['column_list'] = $this->get_show_column();

		$this->_data['info_page'] = $this->_page_content_info;

		$this->load->view('lists', $this->_data);
	}

	//--- used by datatable source data -------
	function lists_ajax() {
		$this->load->helper('mydatatable');
		$table 		= $this->db->dbprefix . $this->_table_name;
		$primaryKey = $this->_table_pk;
		$column_list = $this->get_show_column();
		$columns = array();
		$cnt = 0;
		foreach ($column_list as $key => $value) {
			$columns[] = array(
				'db' 				=> $value['field_name'],
				'dt' 				=> !empty($value['no_order']) ? $value['no_order'] : $cnt,
				'formatter' 		=> !empty($value['result_format']) ? $value['result_format'] : '',
				'show_no_static' 	=> !empty($value['show_no_static']) ? $value['show_no_static'] : '',
			);
			$cnt++;
		}
		generateDataTable($table, $primaryKey, $columns);
	}

	function edit_ajax() {
		$this->_data['source_jenispotongan_masuk'] 		= $this->crudmodel->where_in('jp_kode', array('MT', 'PC'))->get_option_jenispotongan();
		$this->_data['source_jenispotongan_gakmasuk'] 	= $this->crudmodel->where_not_in('jp_kode', array('MT', 'PC'))->get_option_jenispotongan();

		$this->_data['abs_id_karyawan'] = $this->input->post('data_id');
		$this->_data['abs_tanggal'] 	= $this->input->post('txt_tanggal');
		$this->_data['kode'] 			= $this->input->post('txt_kode');

		$this->_data['source_karyawan'] = $this->crudmodel->where(array('id_karyawan' => $this->_data['abs_id_karyawan']))->get_row_karyawan();

		if(!empty($this->_data['kode'])) {
			$data = $this->crudmodel->where(array('abs_id_karyawan' => $this->_data['abs_id_karyawan'], 'abs_tanggal' => $this->_data['abs_tanggal'], 'jp_kode' => $this->_data['kode']))->get_row_result_absen();
		} else {
			$data = $this->crudmodel->where(array('abs_id_karyawan' => $this->_data['abs_id_karyawan'], 'abs_tanggal' => $this->_data['abs_tanggal']))->get_row_result_absen();
		}
		
		$this->_data['data_row'] = $data;

		if(!empty($this->_data['kode'])) {
			$this->_data['data_row_mesin'] = $this->crudmodel->where(array('id_karyawan' => $this->_data['abs_id_karyawan'], 'nDateTime' => $this->_data['abs_tanggal']))->get_row_mesin();
		}

		$this->_data['ajax_action_edit'] 	= site_url($this->_module_controller . 'do_edit_ajax');
		$this->load->view('form_edit', $this->_data);
	}

	function do_edit() {
		$this->load->library('form_validation');

		$this->form_validation->set_rules('abs_id_karyawan', 'Karyawan ID', 'trim|htmlspecialchars|encode_php_tags|prep_for_form|required|xss_clean');
		$this->form_validation->set_rules('id_jenis_potongan', 'Jenis Potongan', 'trim|htmlspecialchars|encode_php_tags|prep_for_form|required|xss_clean');
		
		if($this->form_validation->run()) {
			$abs_id_karyawan 		= $this->input->post('abs_id_karyawan');
			$abs_tanggal 			= $this->input->post('abs_tanggal');
			$kode 					= $this->input->post('kode');
			$id_jenis_potongan 		= $this->input->post('id_jenis_potongan');
			$abs_note 				= $this->input->post('abs_note');
			$sp_izin_status 		= $this->input->post('sp_izin_status');
			$menit_lambat 			= $this->input->post('menit_lambat');
			$menit_cepat 			= $this->input->post('menit_cepat');
			$hd_id_absen 			= $this->input->post('hd_id_absen');

			if(!empty($kode)) {
				if(!empty($menit_lambat)) {
					$res = $this->crudmodel->where(array('jp_kode' => 'MT', 'sp_izin_status' => $sp_izin_status))->order_by('sp_menit_awal', 'DESC')->get_all_jenissanksipotongan();
					foreach ($res as $key => $val) {
						if($menit_lambat >= $val['sp_menit_awal']) {
							$abs_id_sanksi_potongan = $val['id_sanksi_potongan'];
							break;
						}
					}
				}
				if(!empty($menit_cepat)) {
					$res = $this->crudmodel->where(array('jp_kode' => 'PC', 'sp_izin_status' => $sp_izin_status))->order_by('sp_menit_awal', 'DESC')->get_all_jenissanksipotongan();
					foreach ($res as $key => $val) {
						if($menit_cepat >= $val['sp_menit_awal']) {
							$abs_id_sanksi_potongan = $val['id_sanksi_potongan'];
							break;
						}
					}
				}				
			} else {
				$res = $this->crudmodel->where(array('sp_id_jenis_potongan' => $id_jenis_potongan, 'sp_izin_status' => $sp_izin_status))->get_row_sanksipotongan();
				$abs_id_sanksi_potongan = $res['id_sanksi_potongan'];

				if(empty($abs_id_sanksi_potongan)) {
					$this->_data['err_msg'] = 'Jenis potongan ini belum ada!';
					return false;
				}
			}

			if(!empty($hd_id_absen)) {
				$delete = $this->crudmodel->delete_absen(array('id_absen' => $hd_id_absen));
			}

			$admin_data = array(
				'abs_id_karyawan' 			=> $abs_id_karyawan,
				'abs_tanggal' 				=> $abs_tanggal,
				'abs_id_sanksi_potongan' 	=> $abs_id_sanksi_potongan,
				'abs_note' 					=> $abs_note,
			);

			$res = $this->crudmodel->posts_absen($admin_data);
			if($res) {
				$this->_data['success_msg'] = 'Insert data success.';
				return true;
			} else {
				$this->_data['err_msg'] = 'Insert data failed. Please try again.';
				return false;
			}
		} else {
			$this->_data['err_msg'] = validation_errors();
			return FALSE;
		}
	}

	function do_edit_ajax() {
		$res = array(
			'err_msg' 		=> '',
			'success_msg' 	=> '',
		);

		if(!$this->do_edit()) $res['err_msg'] = $this->_data['err_msg'];
		$res['success_msg'] = !empty($this->_data['success_msg']) ? $this->_data['success_msg'] : '';

		echo json_encode($res);
	}

	function do_delete() {
		if($this->input->post('data_id')) {
			$delete = $this->crudmodel->delete_absen(array($this->_table_pk => $this->input->post('data_id')));
			if($delete) {
				$this->_data['success_msg'] = 'Delete data success.';
			} else {
				$this->_data['err_msg'] = 'Delete data failed. Please try again.';
			}
			return $delete;
		} else {
			$this->_data['err_msg'] = 'Data is empty.';
			return false;
		}
	}

	function do_delete_ajax() {
		$res = array(
			'err_msg' 		=> '',
			'success_msg' 	=> '',
		);

		if(!$this->do_delete()) $res['err_msg'] = $this->_data['err_msg'];
		$res['success_msg'] = !empty($this->_data['success_msg']) ? $this->_data['success_msg'] : '';

		echo json_encode($res);
	}
	
}

?>