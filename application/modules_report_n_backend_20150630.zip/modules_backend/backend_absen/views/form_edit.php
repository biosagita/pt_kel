<script type="text/javascript" src="<?php echo $assets; ?>/widgets/parsley/parsley.js"></script>
<script type="text/javascript" src="<?php echo $assets; ?>/widgets/datepicker/datepicker.js"></script>

<script type="text/javascript">
    var enbl_btn_process = true;

    //------submit form ajax module admin----------
    $(function() { "use strict";
        var param = {
            'formid'            : '#dynamic_form',
            'btn_submit'        : '#dynamic_btn_process',
            'div_errmsg'        : '#dynamic_errmsg',
            'url_ajax_action'   : '<?php echo $ajax_action_edit; ?>',
            'data_type'         : 'json',
            'panel_form'        : '#panel_form',
            'panel_list'        : '#panel_list',
            'add_data'          : '#add_data',
            'dynamic_btn_close'   : '#dynamic_btn_close',
            'callback'          : function(data) {
                if(data.err_msg == '') {
                    //refreshTable();
                    /*
                    $.jGrowl(data.success_msg, {
                        sticky: false,
                        position: 'top-right',
                        theme: 'bg-green'
                    });
                    $(param.dynamic_btn_close).trigger('click');
                    */
                    location.reload();
                } else {
                    $(param.div_errmsg).html(data.err_msg);
                    $(param.div_errmsg).show();
                }
                enbl_btn_process = true;
                $(param.btn_submit).attr('disabled', false);
            }
        };

        $(param.formid).submit(function(){
            MYAPP.doFormSubmit.process(param);
            return false;
        });

        $(param.dynamic_btn_close).click(function(e) {
            e.preventDefault();
            $(param.panel_form).empty();
            autoScrolling('html, body');
        });

        $('.bootstrap-datepicker').bsdatepicker({
            format: 'dd-mm-yyyy'
        });
    });
</script>

<div class="panel-body">
	<h3 class="title-hero">
	    Edit Data
	</h3>
	<?php if(!empty($form_errmsg)) : ?>
        <div class="alert alert-danger">
            <p><?php echo $form_errmsg; ?></p>
        </div>
    <?php endif; ?>

    <div id="dynamic_errmsg" class="alert alert-danger" style="display:none">
        <p></p>
    </div>
	<div class="example-box-wrapper">
        <form method="post" class="form-horizontal bordered-row" id="dynamic_form" data-parsley-validate>
            <input type="hidden" name="hd_id_absen" value="<?php echo (!empty($data_row['id_absen']) ? $data_row['id_absen'] : ''); ?>" />
            <input type="hidden" name="abs_id_karyawan" value="<?php echo $abs_id_karyawan; ?>" />
            <input type="hidden" name="abs_tanggal" value="<?php echo $abs_tanggal; ?>" />
            <input type="hidden" name="kode" value="<?php echo $kode; ?>" />

            <div class="form-group">
                <label class="col-sm-3 control-label">Nama</label>
                <div class="col-sm-6">
                    <input class="form-control" name="nama_lengkap" id="nama_lengkap" value="<?php echo $source_karyawan['nama_lengkap']; ?>" disabled />
                </div>
            </div>

            <?php if(!empty($kode)) : ?>
            <div class="form-group">
                <label class="col-sm-3 control-label">Jenis Potongan</label>
                <div class="col-sm-6">
                    <?php if($kode == 'MT') : ?>
                    <input type="hidden" name="menit_lambat" value="<?php echo (!empty($data_row_mesin['nLateInTime']) ? $data_row_mesin['nLateInTime'] : ''); ?>" />
                    <input class="form-control" name="jp_nama" id="jp_nama" value="<?php echo ($source_jenispotongan_masuk['MT']['name'] . ' (' . $data_row_mesin['nLateInTime'] . ' menit)'); ?>" disabled />
                    <?php endif; ?>
                    <?php if($kode == 'PC') : ?>
                    <input type="hidden" name="menit_cepat" value="<?php echo (!empty($data_row_mesin['nEarlyOutTime']) ? $data_row_mesin['nEarlyOutTime'] : ''); ?>" />
                    <input class="form-control" name="jp_nama" id="jp_nama" value="<?php echo ($source_jenispotongan_masuk['PC']['name'] . ' (' . $data_row_mesin['nEarlyOutTime'] . ' menit)'); ?>" disabled />
                    <?php endif; ?>
                </div>
            </div>
            <?php else : ?>
            <div class="form-group">
                <label class="col-sm-3 control-label">Jenis Potongan</label>
                <div class="col-sm-6">
                    <select class="form-control" name="id_jenis_potongan" id="id_jenis_potongan">
                        <option value="">-- Choose --</option>
                        <?php foreach($source_jenispotongan_gakmasuk as $vOpt) : ?>
                            <?php 
                                $selected = '';
                                if($vOpt['value'] == $data_row['id_jenis_potongan']) $selected = 'selected';
                            ?>
                            <option value="<?php echo $vOpt['value']; ?>" <?php echo $selected; ?>><?php echo $vOpt['name']; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>
            <?php endif; ?>        

            <div class="form-group">
                <label class="col-sm-3 control-label">Keterangan</label>
                <div class="col-sm-6">
                    <?php
                    $abs_note = '';
                        if(!empty($kode)) {
                            if($data_row['jp_kode'] == 'MT') $abs_note = $data_row['abs_note'];
                            if($data_row['jp_kode'] == 'PC') $abs_note = $data_row['abs_note'];
                        } else {
                            $abs_note = $data_row['abs_note'];
                        }
                    ?>
                    <textarea class="form-control" name="abs_note" id="abs_note"><?php echo (!empty($abs_note) ? $abs_note : ''); ?></textarea>
                </div>
            </div>

            <div class="form-group">
                <label class="col-sm-3 control-label">Izin</label>
                <div class="col-sm-6">
                    <input type="checkbox" name="sp_izin_status" id="sp_izin_status" value="1" <?php echo (!empty($data_row['sp_izin_status']) ? 'checked' : ''); ?> />
                </div>
            </div>

            <div class="bg-default content-box text-center pad20A mrg25T">
                <button class="btn btn-success" id="dynamic_btn_process">Process</button>
                <button type="reset" class="btn btn-primary" id="dynamic_btn_process">Reset</button>
                <button class="btn btn-black" id="dynamic_btn_close">Close</button>
            </div>
        </form>
    </div>
</div>