<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Rekapkebnorek extends MY_Report {

	function __construct(){
		parent::__construct();

		if(!$this->session->userdata('admin_id')) {
			redirect('backend_login/login');
			exit();
		}

		$this->load->model('report_model', 'report');
	}
	
	function index() {

		if(!empty($_GET['txt_tanggal_awal']) AND !empty($_GET['txt_tanggal_akhir'])) {
			$this->do_submit();
		}

		$this->template->set('title', 'Rekap Keb Norek');
		$this->template->set('assets', $this->_data['assets']);
		$this->template->load('template_report/main', 'lists', $this->_data);
	}

	private function do_submit() {
		$this->_data['txt_tanggal_awal'] 	= $_GET['txt_tanggal_awal'];
		$this->_data['txt_tanggal_akhir'] 	= $_GET['txt_tanggal_akhir'];
		$this->_data['txt_kurang'] 			= !empty($_GET['txt_kurang']) ? $_GET['txt_kurang'] : 0;
		$this->_data['txt_sisa'] 			= !empty($_GET['txt_sisa']) ? $_GET['txt_sisa'] : 0;

		$strtotime_tanggal_awal 	= strtotime($this->_data['txt_tanggal_awal']);
		$strtotime_tanggal_akhir 	= strtotime($this->_data['txt_tanggal_akhir']);

		if($strtotime_tanggal_awal > $strtotime_tanggal_akhir) {
			$this->_data['error'] = '<p>Tanggal akhir harus lebih sama dengan tanggal awal</p>';
			return false;
		}

		$this->_data['periode'] = date('d F Y', $strtotime_tanggal_awal) . ' s/d ' . date('d F Y', $strtotime_tanggal_akhir);
		$this->_data['result_grade'] = $this->report->get_all_grade();
		$this->_data['result'] = $this->report->get_all_karyawan();
		$this->get_netto_karyawan();

		$this->_data['kelas_grade'] = array();
		$this->_data['total_tunjangan'] = 0;
		$this->_data['jumlah_pegawai'] 	= 0;
		foreach ($this->_data['result'] as $val) {
			if(empty($this->_data['kelas_grade'][$val['kelas_grade']])) {
				$this->_data['kelas_grade'][$val['kelas_grade']] = 1;
			} else {
				$this->_data['kelas_grade'][$val['kelas_grade']] += 1;
			}

			$this->_data['total_tunjangan'] += $val['tunjangan'];
			$this->_data['jumlah_pegawai']++;
		}

		$this->_data['total_karyawan'] = !empty($this->_data['kelas_grade']) ? array_sum($this->_data['kelas_grade']) : 0;
		$this->_data['pajak'] = get_pph21($this->_data['total_tunjangan']);
		$this->_data['total_potongan'] = !empty($this->_data['potongan']) ? array_sum($this->_data['potongan']) : 0;
		$this->_data['total_kebutuhan'] = $this->_data['total_tunjangan'] + $this->_data['txt_kurang'] - ($this->_data['total_potongan'] + $this->_data['txt_sisa']);
	}

	function export_excel() {
		$this->do_submit();
		
		//load our new PHPExcel library
		$this->load->library('excel');
		//activate worksheet number 1
		$this->excel->setActiveSheetIndex(0);
		//name the worksheet
		$this->excel->getActiveSheet()->setTitle('Transfer BRI');

		$this->excel->getDefaultStyle()->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);

		$this->excel->getActiveSheet()->getColumnDimension('A')->setWidth(30);
		$this->excel->getActiveSheet()->getColumnDimension('B')->setWidth(30);
		$this->excel->getActiveSheet()->getColumnDimension('C')->setWidth(30);
		$this->excel->getActiveSheet()->getColumnDimension('D')->setWidth(30);
		$this->excel->getActiveSheet()->getColumnDimension('E')->setWidth(30);

		$this->excel->getActiveSheet()->setCellValue('A7', '1');
		$this->excel->getActiveSheet()->setCellValue('B7', '2');
		$this->excel->getActiveSheet()->setCellValue('C7', '3');
		$this->excel->getActiveSheet()->setCellValue('D7', '4');
		$this->excel->getActiveSheet()->setCellValue('E7', '5');
		$this->excel->getActiveSheet()->setCellValue('F7', '6');

		$next_char = 'F';
		foreach($this->_data['result_grade'] as $val) { 
			$this->excel->getActiveSheet()->getColumnDimension($next_char)->setWidth(20);
			$this->excel->getActiveSheet()->setCellValue(($next_char. '6'), $val['kelas_grade']);
			$last_char_grade = $next_char;
			$next_char++;
		}
		$last_char_label = $last_char_nomor = $next_char;

		$this->excel->getActiveSheet()->mergeCells('F7:'.$last_char_grade.'7');

		$this->excel->getActiveSheet()->getColumnDimension($next_char)->setWidth(30);
		$this->excel->getActiveSheet()->getColumnDimension(++$next_char)->setWidth(30);
		$this->excel->getActiveSheet()->getColumnDimension(++$next_char)->setWidth(30);
		$this->excel->getActiveSheet()->getColumnDimension(++$next_char)->setWidth(30);
		$this->excel->getActiveSheet()->getColumnDimension(++$next_char)->setWidth(30);
		$this->excel->getActiveSheet()->getColumnDimension(++$next_char)->setWidth(30);
		$this->excel->getActiveSheet()->getColumnDimension(++$next_char)->setWidth(30);
		$this->excel->getActiveSheet()->getColumnDimension(++$next_char)->setWidth(30);

		$cnt_nomor = 7;
		$this->excel->getActiveSheet()->setCellValue(($last_char_nomor . '7'), $cnt_nomor);
		$this->excel->getActiveSheet()->setCellValue((++$last_char_nomor . '7'), ++$cnt_nomor);
		$this->excel->getActiveSheet()->setCellValue((++$last_char_nomor . '7'), ++$cnt_nomor);
		$this->excel->getActiveSheet()->setCellValue((++$last_char_nomor . '7'), ++$cnt_nomor);
		$this->excel->getActiveSheet()->setCellValue((++$last_char_nomor . '7'), ++$cnt_nomor);
		$this->excel->getActiveSheet()->setCellValue((++$last_char_nomor . '7'), ++$cnt_nomor);
		$this->excel->getActiveSheet()->setCellValue((++$last_char_nomor . '7'), ++$cnt_nomor);
		$this->excel->getActiveSheet()->setCellValue((++$last_char_nomor . '7'), ++$cnt_nomor);

		//set cell A1 content with some text
		$this->excel->getActiveSheet()->setCellValue('A1', 'REKAPITULASI KEBUTUHAN PEMBAYARAN TUNJANGAN KINERJA');
		$this->excel->getActiveSheet()->setCellValue('A2', 'KANTOR IMIGRASI KELAS I JAKARTA UTARA');
		$this->excel->getActiveSheet()->setCellValue('A3', 'TANGGAL : ' . $this->_data['periode']);
		$this->excel->getActiveSheet()->getStyle('A1')->getFont()->setBold(true);	
		$this->excel->getActiveSheet()->getStyle('A2')->getFont()->setBold(true);
		$this->excel->getActiveSheet()->getStyle('A3')->getFont()->setBold(true);
		$this->excel->getActiveSheet()->mergeCells('A1:'.$next_char.'1');
		$this->excel->getActiveSheet()->mergeCells('A2:'.$next_char.'2');
		$this->excel->getActiveSheet()->mergeCells('A3:'.$next_char.'3');

		$this->excel->getActiveSheet()->setCellValue('A5', 'NO.');
		$this->excel->getActiveSheet()->setCellValue('B5', 'NAMA KANTOR/UPT');
		$this->excel->getActiveSheet()->setCellValue('C5', 'NOMOR REKENING BANK');
		$this->excel->getActiveSheet()->setCellValue('D5', 'NAMA BANK');
		$this->excel->getActiveSheet()->setCellValue('E5', 'TOTAL KEBUTUHAN');

		$this->excel->getActiveSheet()->setCellValue('F5', 'GRADE');
		$this->excel->getActiveSheet()->mergeCells('F5:'.$last_char_grade.'5');

		$this->excel->getActiveSheet()->setCellValue(($last_char_label.'5'), 'JUMLAH PEGAWAI');
		$this->excel->getActiveSheet()->setCellValue((++$last_char_label.'5'), 'JUMLAH TUNJANGAN KINERJA');
		$this->excel->getActiveSheet()->setCellValue((++$last_char_label.'5'), 'PAJAK');
		$this->excel->getActiveSheet()->setCellValue((++$last_char_label.'5'), 'FAKTOR PENGURANG');
		$this->excel->getActiveSheet()->setCellValue((++$last_char_label.'5'), 'KEKURANGAN BULAN LALU');
		$this->excel->getActiveSheet()->setCellValue((++$last_char_label.'5'), 'SISA DANA BULAN LALU');
		$this->excel->getActiveSheet()->setCellValue((++$last_char_label.'5'), 'TOTAL KEBUTUHAN');
		$this->excel->getActiveSheet()->setCellValue((++$last_char_label.'5'), 'KET');

		$this->excel->getActiveSheet()->getStyle('A5:'.$next_char.'5')->getFont()->setBold(true);
		$this->excel->getActiveSheet()->getStyle('A6:'.$next_char.'6')->getFont()->setBold(true);
		$this->excel->getActiveSheet()->getStyle('A7:'.$next_char.'7')->getFont()->setBold(true);
		

		$cnt_row = 8;
		$no = 1;

		$this->excel->getActiveSheet()->setCellValue(('A'.$cnt_row), $no);
		$this->excel->getActiveSheet()->setCellValue(('B'.$cnt_row), 'KANTOR IMIGRASI KELAS I JAKARTA UTARA');
		$this->excel->getActiveSheet()->setCellValue(('C'.$cnt_row), '186.049.001');
		$this->excel->getActiveSheet()->setCellValue(('D'.$cnt_row), 'BNI');
		$this->excel->getActiveSheet()->setCellValue(('E'.$cnt_row), 'Bendahara Pengeluaran Kantor Imigrasi Klas I Jakarta Utara');

		$next_char = 'F';
		foreach($this->_data['result_grade'] as $val) {
			$this->excel->getActiveSheet()->setCellValue(($next_char.$cnt_row), (!empty($this->_data['kelas_grade'][$val['kelas_grade']]) ? $this->_data['kelas_grade'][$val['kelas_grade']] : '-'));
			$next_char++;
		}
		$last_char_jumlah = $next_char;

		$this->excel->getActiveSheet()->setCellValue(($next_char.$cnt_row), (!empty($this->_data['total_karyawan']) ? $this->_data['total_karyawan'] : '-'));
		$this->excel->getActiveSheet()->setCellValue((++$next_char.$cnt_row), (!empty($this->_data['total_tunjangan']) ? number_format($this->_data['total_tunjangan'], 0 , ',', '.') : '-'));
		$this->excel->getActiveSheet()->setCellValue((++$next_char.$cnt_row), (!empty($this->_data['pajak']) ? number_format($this->_data['pajak'], 0 , ',', '.') : '-'));
		$this->excel->getActiveSheet()->setCellValue((++$next_char.$cnt_row), (!empty($this->_data['total_potongan']) ? number_format($this->_data['total_potongan'], 0 , ',', '.') : '-'));
		$this->excel->getActiveSheet()->setCellValue((++$next_char.$cnt_row), (!empty($this->_data['txt_kurang']) ? number_format($this->_data['txt_kurang'], 0 , ',', '.') : '-'));
		$this->excel->getActiveSheet()->setCellValue((++$next_char.$cnt_row), (!empty($this->_data['txt_sisa']) ? number_format($this->_data['txt_sisa'], 0 , ',', '.') : '-'));
		$this->excel->getActiveSheet()->setCellValue((++$next_char.$cnt_row), (!empty($this->_data['total_kebutuhan']) ? number_format($this->_data['total_kebutuhan'], 0 , ',', '.') : '-'));

		$cnt_row = 9;

		$this->excel->getActiveSheet()->setCellValue(('A'.$cnt_row), 'JUMLAH');
		$this->excel->getActiveSheet()->mergeCells(('A'.$cnt_row).':'.$last_char_grade.$cnt_row);

		$this->excel->getActiveSheet()->setCellValue(($last_char_jumlah.$cnt_row), (!empty($this->_data['total_karyawan']) ? $this->_data['total_karyawan'] : '-'));
		$this->excel->getActiveSheet()->setCellValue((++$last_char_jumlah.$cnt_row), (!empty($this->_data['total_tunjangan']) ? number_format($this->_data['total_tunjangan'], 0 , ',', '.') : '-'));
		$this->excel->getActiveSheet()->setCellValue((++$last_char_jumlah.$cnt_row), (!empty($this->_data['pajak']) ? number_format($this->_data['pajak'], 0 , ',', '.') : '-'));
		$this->excel->getActiveSheet()->setCellValue((++$last_char_jumlah.$cnt_row), (!empty($this->_data['total_potongan']) ? number_format($this->_data['total_potongan'], 0 , ',', '.') : '-'));
		$this->excel->getActiveSheet()->setCellValue((++$last_char_jumlah.$cnt_row), (!empty($this->_data['txt_kurang']) ? number_format($this->_data['txt_kurang'], 0 , ',', '.') : '-'));
		$this->excel->getActiveSheet()->setCellValue((++$last_char_jumlah.$cnt_row), (!empty($this->_data['txt_sisa']) ? number_format($this->_data['txt_sisa'], 0 , ',', '.') : '-'));
		$this->excel->getActiveSheet()->setCellValue((++$last_char_jumlah.$cnt_row), (!empty($this->_data['total_kebutuhan']) ? number_format($this->_data['total_kebutuhan'], 0 , ',', '.') : '-'));

		$filename='report_rekap_keb_norek_'.time().'.xls'; //save our workbook as this file name
		header('Content-Type: application/vnd.ms-excel'); //mime type
		header('Content-Disposition: attachment;filename="'.$filename.'"'); //tell browser what's the file name
		header('Cache-Control: max-age=0'); //no cache
		            
		//save it to Excel5 format (excel 2003 .XLS file), change this to 'Excel2007' (and adjust the filename extension, also the header mime type)
		//if you want to save it as .XLSX Excel 2007 format
		$objWriter = PHPExcel_IOFactory::createWriter($this->excel, 'Excel5');  
		//force user to download the Excel file without writing it to server's HD
		$objWriter->save('php://output');
	}

	private function get_netto_karyawan() {
		$strtotime_tanggal_awal 	= strtotime(($this->_data['txt_tanggal_awal'] . ' 00:00:00'));
		$strtotime_tanggal_akhir 	= strtotime(($this->_data['txt_tanggal_akhir'] . ' 23:59:00'));

		$res_potongan 		= $this->report->get_all_sanksipotongan();
		$res_potongan_masuk = $this->report->order_by('sp_menit_awal', 'DESC')->get_all_sanksipotonganmasuk();
		$res_gakmasuk 		= $this->report->where(array('abs_tanggal >=' => $strtotime_tanggal_awal, 'abs_tanggal <=' => $strtotime_tanggal_akhir))->get_all_gakmasuk();
		$res_gakmasukmesin 	= $this->report->where(array('abs_tanggal >=' => $strtotime_tanggal_awal, 'abs_tanggal <=' => $strtotime_tanggal_akhir))->get_all_gakmasukmesin();
		$res_masuk 			= $this->report->where(array('nDateTime >=' => $strtotime_tanggal_awal, 'nDateTime <=' => $strtotime_tanggal_akhir))->get_all_masuk();
		
		$this->_data['potongan'] = array();

		$history = array();
		
		foreach ($res_masuk as $val) {
			$history[$val['nDateTime']][$val['id_karyawan']] = 1;

			if(!empty($res_gakmasuk[$val['id_karyawan']][$val['nDateTime']])) continue;
			if(!empty($res_gakmasukmesin[$val['id_karyawan']][$val['nDateTime']]['MT'])) $val['nLateInTime'] = 0;
			if(!empty($res_gakmasukmesin[$val['id_karyawan']][$val['nDateTime']]['PC'])) $val['nEarlyOutTime'] = 0;

			if(empty($val['nLateInTime']) AND empty($val['nEarlyOutTime'])) continue;

			if(empty($this->_data['potongan'][$val['id_karyawan']])) {
				$this->_data['potongan'][$val['id_karyawan']] = $this->get_potongan_absensi($val, $res_potongan_masuk);
			} else {
				$this->_data['potongan'][$val['id_karyawan']] += $this->get_potongan_absensi($val, $res_potongan_masuk);
			}
		}

		//hitung potongan karyawan yg gak masuk, yang beralasan kecuali karyawan masuk terlambat n pulang cepat
		foreach ($res_gakmasuk as $vId) {
			foreach ($vId as $val) {
				foreach ($val as $vAkhir) {
					$history[$vAkhir['abs_tanggal']][$vAkhir['id_karyawan']] = 1;

					if(empty($this->_data['potongan'][$vAkhir['id_karyawan']])) {
						$this->_data['potongan'][$vAkhir['id_karyawan']] = round(($vAkhir['tunjangan'] / 100) * $res_potongan[$vAkhir['jp_kode']][$vAkhir['id_sanksi_potongan']]['persentase']);
					} else {
						$this->_data['potongan'][$vAkhir['id_karyawan']] += round(($vAkhir['tunjangan'] / 100) * $res_potongan[$vAkhir['jp_kode']][$vAkhir['id_sanksi_potongan']]['persentase']);
					}
				}
			}
		}

		//hitung potongan karyawan yg gak masuk hanya karyawan masuk terlambat n pulang cepat
		foreach ($res_gakmasukmesin as $vId) {
			foreach ($vId as $vax) {
				foreach ($vax as $val) {
					foreach ($val as $vAkhir) {
						$history[$vAkhir['abs_tanggal']][$vAkhir['id_karyawan']] = 1;

						if(empty($this->_data['potongan'][$vAkhir['id_karyawan']])) {
							$this->_data['potongan'][$vAkhir['id_karyawan']] = round(($vAkhir['tunjangan'] / 100) * $res_potongan[$vAkhir['jp_kode']][$vAkhir['id_sanksi_potongan']]['persentase']);
						} else {
							$this->_data['potongan'][$vAkhir['id_karyawan']] += round(($vAkhir['tunjangan'] / 100) * $res_potongan[$vAkhir['jp_kode']][$vAkhir['id_sanksi_potongan']]['persentase']);
						}
					}
				}
			}
		}

		//hitung potongan karyawan yg gak masuk yang gak beralasan
		if(!empty($history)) {
			foreach ($this->_data['result'] as $key => $val) {
				foreach ($history as $kHistory => $vHistory) {
					if(!empty($history[$kHistory][$val['id_karyawan']])) continue;

					if(empty($this->_data['potongan'][$val['id_karyawan']])) {
						$this->_data['potongan'][$val['id_karyawan']] = round(($val['tunjangan'] / 100) * $res_potongan['TM'][1]['persentase']);
					} else {
						$this->_data['potongan'][$val['id_karyawan']] += round(($val['tunjangan'] / 100) * $res_potongan['TM'][1]['persentase']);
					}
				}
			}
		}
	}

	private function get_potongan_absensi($val, $res_potongan_masuk) {
		$potongan 	= 0;
		if($val['nLateInTime'] > 0) {
			foreach ($res_potongan_masuk['MT'][0] as $value) {
				if($val['nLateInTime'] >= $value['sp_menit_awal']) {
					$persentase = $value['persentase'];
					break;
				}
			}
			$potongan += round(($val['tunjangan'] / 100) * $persentase);
		}
		if($val['nEarlyOutTime'] > 0) {
			foreach ($res_potongan_masuk['PC'][0] as $value) {
				if($val['nEarlyOutTime'] >= $value['sp_menit_awal']) {
					$persentase = $value['persentase'];
					break;
				}
			}
			$potongan += round(($val['tunjangan'] / 100) * $persentase);
		}
		return $potongan;
	}

	function do_print() {
		$this->do_submit();

		$this->template->load('template_print/main_landscape', 'print', $this->_data);
	}
}

?>