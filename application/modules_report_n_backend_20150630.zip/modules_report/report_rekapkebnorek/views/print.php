<?php if(!empty($periode)): ?>
<div class="row report">
    <p>REKAPITULASI KEBUTUHAN PEMBAYARAN TUNJANGAN KINERJA<br />KANTOR IMIGRASI KELAS I JAKARTA UTARA<br />UNTUK TANGGAL : <?php echo $periode; ?></p>
    <div class="table-responsive">
        <table class="table table-striped table-bordered table-condensed">
            <thead class="gray">
                <tr>
                    <th rowspan="2">NO.</th>
                    <th rowspan="2">UPT/KANTOR</th>
                    <th rowspan="2">NOMOR REKENING BANK</th>
                    <th rowspan="2">NAMA BANK</th>
                    <th rowspan="2">NAMA REKENING SESUAI DENGAN REKENING KORAN</th>
                    <th colspan="<?php echo count($result_grade); ?>">GRADE</th>
                    <th rowspan="2">JUMLAH PEGAWAI</th>
                    <th rowspan="2">JUMLAH TUNJANGAN KINERJA</th>
                    <th rowspan="2">PAJAK</th>
                    <th rowspan="2">FAKTOR PENGURANG</th>
                    <th rowspan="2">KEKURANGAN BULAN LALU</th>
                    <th rowspan="2">SISA DANA BULAN LALU</th>
                    <th rowspan="2">TOTAL KEBUTUHAN</th>
                    <th rowspan="2">KET</th>
                </tr>
                <tr>
                    <?php foreach($result_grade as $val) : ?>
                    <th><?php echo $val['kelas_grade']; ?></th>
                    <?php endforeach; ?>
                </tr>
                <tr>
                    <th>1</th>
                    <th>2</th>
                    <th>3</th>
                    <th>4</th>
                    <th>5</th>
                    <th colspan="<?php echo count($result_grade); ?>">6</th>
                    <th>7</th>
                    <th>8</th>
                    <th>9</th>
                    <th>10</th>
                    <th>11</th>
                    <th>12</th>
                    <th>13</th>
                    <th>14</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>1</td>
                    <td><div style="width:200px;">KANTOR IMIGRASI KELAS I JAKARTA UTARA</div></td>
                    <td>186.049.001</td>
                    <td>BNI</td>
                    <td><div style="width:250px;">Bendahara Pengeluaran Kantor Imigrasi Klas I Jakarta Utara</div></td>
                    <?php foreach($result_grade as $val) : ?>
                    <td><?php echo (!empty($kelas_grade[$val['kelas_grade']]) ? $kelas_grade[$val['kelas_grade']] : '-'); ?></td>
                    <?php endforeach; ?>
                    <td><?php echo (!empty($total_karyawan) ? $total_karyawan : '-'); ?></td>
                    <td><div style="text-align:right;"><?php echo (!empty($total_tunjangan) ? number_format($total_tunjangan, 0 , ',', '.') : '-'); ?></div></td>
                    <td><div style="text-align:right;"><?php echo (!empty($pajak) ? number_format($pajak, 0 , ',', '.') : '-'); ?></div></td>
                    <td><div style="text-align:right;"><?php echo (!empty($total_potongan) ? number_format($total_potongan, 0 , ',', '.') : '-'); ?></div></td>
                    <td><div style="text-align:right;"><?php echo (!empty($txt_kurang) ? number_format($txt_kurang, 0 , ',', '.') : '-'); ?></div></td>
                    <td><div style="text-align:right;"><?php echo (!empty($txt_sisa) ? number_format($txt_sisa, 0 , ',', '.') : '-'); ?></div></td>
                    <td><div style="text-align:right;"><?php echo (!empty($total_kebutuhan) ? number_format($total_kebutuhan, 0 , ',', '.') : '-'); ?></div></td>
                    <td></td>
                </tr>
                <tr class="jumlah">
                    <td colspan="<?php echo (5 + count($result_grade)); ?>">Jumlah</td>
                    <td><?php echo (!empty($total_karyawan) ? $total_karyawan : '-'); ?></td>
                    <td><div style="text-align:right;"><?php echo (!empty($total_tunjangan) ? number_format($total_tunjangan, 0 , ',', '.') : '-'); ?></div></td>
                    <td><div style="text-align:right;"><?php echo (!empty($pajak) ? number_format($pajak, 0 , ',', '.') : '-'); ?></div></td>
                    <td><div style="text-align:right;"><?php echo (!empty($total_potongan) ? number_format($total_potongan, 0 , ',', '.') : '-'); ?></div></td>
                    <td><div style="text-align:right;"><?php echo (!empty($txt_kurang) ? number_format($txt_kurang, 0 , ',', '.') : '-'); ?></div></td>
                    <td><div style="text-align:right;"><?php echo (!empty($txt_sisa) ? number_format($txt_sisa, 0 , ',', '.') : '-'); ?></div></td>
                    <td><div style="text-align:right;"><?php echo (!empty($total_kebutuhan) ? number_format($total_kebutuhan, 0 , ',', '.') : '-'); ?></div></td>
                    <td></td>
                </tr>
            </tbody>
        </table>
    </div>
</div>
<?php endif; ?>