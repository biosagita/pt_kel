<?php if(!empty($periode)): ?>
<div class="row report">
    <p>TANDA TERIMA TUNJANGAN KINERJA PEGAWAI<br />KEMENTERIAN HUKUM DAN HAM R.I<br />KANTOR IMIGRASI KELAS I JAKARTA UTARA<br />UNTUK TANGGAL : <?php echo $periode; ?></p>
    <div class="table-responsive">
        <table class="table table-striped table-bordered table-condensed">
            <thead class="gray">
                <tr>
                    <th>NO.</th>
                    <th>NAMA / NIP</th>
                    <th>GOL</th>
                    <th>JABATAN</th>
                    <th>GRADE</th>
                    <th>BESARAN TUNJANGAN</th>
                    <th>TUNJ. PPH 21</th>
                    <th>BRUTO</th>
                    <th>POT.PPH 21</th>
                    <th>FAKTOR PENGURANG</th>
                    <th>NETTO</th>
                    <th>TANDA TANGAN</th>
                </tr>
                <tr>
                    <th>1</th>
                    <th>2</th>
                    <th>3</th>
                    <th>4</th>
                    <th>5</th>
                    <th>6</th>
                    <th>7 ( 6*....% )</th>
                    <th>8 ( 6+7 )</th>
                    <th>9 ( 6*....% )</th>
                    <th>10</th>
                    <th>11 ( 8 - 9 - 10 )</th>
                    <th>12</th>
                </tr>
            </thead>
            <tbody>
                <?php
                    $total_besaran_tunjangan    = 0;
                    $total_tunjangan_pph21      = 0;
                    $total_bruto                = 0;
                    $total_potongan_pph21       = 0;
                    $total_faktor_pengurang     = 0;
                    $total_netto                = 0;
                ?>
                <?php foreach($result as $key => $val) : ?>
                <?php
                    $besaran_tunjangan  = $val['tunjangan'];
                    $tunjangan_pph21    = $potongan_pph21  = get_pph21($besaran_tunjangan);
                    $bruto              = $besaran_tunjangan + $tunjangan_pph21;
                    $faktor_pengurang   = !empty($potongan[$val['id_karyawan']]) ? $potongan[$val['id_karyawan']] : 0;
                    $netto              = !empty($potongan[$val['id_karyawan']]) ? ($val['tunjangan'] - $potongan[$val['id_karyawan']]) : $val['tunjangan'];

                    $total_besaran_tunjangan    += $besaran_tunjangan;
                    $total_tunjangan_pph21      += $tunjangan_pph21;
                    $total_bruto                += $bruto;
                    $total_potongan_pph21       += $potongan_pph21;
                    $total_faktor_pengurang     += $faktor_pengurang;
                    $total_netto                += $netto;
                ?>
                <tr>
                    <td><?php echo ($key+1); ?></td>
                    <td><div style="text-align:left;"><?php echo $val['nama_lengkap']; ?><br />NIP. <?php echo $val['nip']; ?></div></td>
                    <td><div style="text-align:left;"><?php echo $val['nama_golongan']; ?></div></td>
                    <td><div style="text-align:left;"><?php echo $val['nama_jabatan']; ?></div></td>
                    <td><?php echo $val['kelas_grade']; ?></td>
                    <td><div style="text-align:right;"><?php echo (!empty($besaran_tunjangan) ? number_format($besaran_tunjangan, 0, ',', '.') : '-'); ?></div></td>
                    <td><div style="text-align:right;"><?php echo (!empty($tunjangan_pph21) ? number_format($tunjangan_pph21, 0, ',', '.') : '-'); ?></div></td>
                    <td><div style="text-align:right;"><?php echo (!empty($bruto) ? number_format($bruto, 0, ',', '.') : '-'); ?></div></td>
                    <td><div style="text-align:right;"><?php echo (!empty($potongan_pph21) ? number_format($potongan_pph21, 0, ',', '.') : '-'); ?></div></td>
                    <td><div style="text-align:right;"><?php echo (!empty($faktor_pengurang) ? number_format($faktor_pengurang, 0, ',', '.') : '-'); ?></div></td>
                    <td><div style="text-align:right;"><?php echo (!empty($netto) ? (number_format($netto, 0, ',', '.')) : '-'); ?></div></td>
                    <td></td>
                </tr>
                <?php endforeach; ?>
                <tr class="jumlah">
                    <td colspan="5">Jumlah</td>
                    <td><div style="text-align:right;"><?php echo (!empty($total_besaran_tunjangan) ? (number_format($total_besaran_tunjangan, 0, ',', '.')) : '-'); ?></div></td>
                    <td><div style="text-align:right;"><?php echo (!empty($total_tunjangan_pph21) ? (number_format($total_tunjangan_pph21, 0, ',', '.')) : '-'); ?></div></td>
                    <td><div style="text-align:right;"><?php echo (!empty($total_bruto) ? (number_format($total_bruto, 0, ',', '.')) : '-'); ?></div></td>
                    <td><div style="text-align:right;"><?php echo (!empty($total_potongan_pph21) ? (number_format($total_potongan_pph21, 0, ',', '.')) : '-'); ?></div></td>
                    <td><div style="text-align:right;"><?php echo (!empty($total_faktor_pengurang) ? (number_format($total_faktor_pengurang, 0, ',', '.')) : '-'); ?></div></td>
                    <td><div style="text-align:right;"><?php echo (!empty($total_netto) ? (number_format($total_netto, 0, ',', '.')) : '-'); ?></div></td>
                    <td></td>
                </tr>
            </tbody>
        </table>
    </div>
</div>
<?php endif; ?>