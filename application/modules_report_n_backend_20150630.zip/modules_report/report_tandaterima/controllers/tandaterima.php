<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Tandaterima extends MY_Report {

	function __construct(){
		parent::__construct();

		if(!$this->session->userdata('admin_id')) {
			redirect('backend_login/login');
			exit();
		}

		$this->load->model('report_model', 'report');
	}
	
	function index() {

		if(!empty($_GET['txt_tanggal_awal']) AND !empty($_GET['txt_tanggal_akhir'])) {
			$this->do_submit();
		}

		$this->template->set('title', 'Tanda Terima');
		$this->template->set('assets', $this->_data['assets']);
		$this->template->load('template_report/main', 'lists', $this->_data);
	}

	private function do_submit() {
		$this->_data['txt_tanggal_awal'] 	= $_GET['txt_tanggal_awal'];
		$this->_data['txt_tanggal_akhir'] 	= $_GET['txt_tanggal_akhir'];

		$strtotime_tanggal_awal 	= strtotime($this->_data['txt_tanggal_awal']);
		$strtotime_tanggal_akhir 	= strtotime($this->_data['txt_tanggal_akhir']);

		if($strtotime_tanggal_awal > $strtotime_tanggal_akhir) {
			$this->_data['error'] = '<p>Tanggal akhir harus lebih sama dengan tanggal awal</p>';
			return false;
		}

		$this->_data['periode'] = date('d F Y', $strtotime_tanggal_awal) . ' s/d ' . date('d F Y', $strtotime_tanggal_akhir);
		$this->_data['result'] = $this->report->get_all_karyawan();
		$this->get_netto_karyawan();
	}

	function export_excel() {
		$this->do_submit();

		//load our new PHPExcel library
		$this->load->library('excel');
		//activate worksheet number 1
		$this->excel->setActiveSheetIndex(0);
		//name the worksheet
		$this->excel->getActiveSheet()->setTitle('Tanda Terima');

		$this->excel->getDefaultStyle()->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);

		$this->excel->getActiveSheet()->getColumnDimension('B')->setWidth(30);
		$this->excel->getActiveSheet()->getColumnDimension('C')->setWidth(30);
		$this->excel->getActiveSheet()->getColumnDimension('D')->setWidth(30);
		$this->excel->getActiveSheet()->getColumnDimension('E')->setWidth(30);
		$this->excel->getActiveSheet()->getColumnDimension('F')->setWidth(30);
		$this->excel->getActiveSheet()->getColumnDimension('G')->setWidth(30);
		$this->excel->getActiveSheet()->getColumnDimension('H')->setWidth(30);
		$this->excel->getActiveSheet()->getColumnDimension('I')->setWidth(30);
		$this->excel->getActiveSheet()->getColumnDimension('J')->setWidth(30);
		$this->excel->getActiveSheet()->getColumnDimension('K')->setWidth(30);
		$this->excel->getActiveSheet()->getColumnDimension('L')->setWidth(30);

		//make the font become bold
		$this->excel->getActiveSheet()->getStyle('A2')->getFont()->setBold(true);
		$this->excel->getActiveSheet()->getStyle('A3')->getFont()->setBold(true);
		$this->excel->getActiveSheet()->getStyle('A4')->getFont()->setBold(true);
		$this->excel->getActiveSheet()->getStyle('A5')->getFont()->setBold(true);
		$this->excel->getActiveSheet()->getStyle('A6')->getFont()->setBold(true);

		$this->excel->getActiveSheet()->getStyle('A8:L8')->getFont()->setBold(true);
		$this->excel->getActiveSheet()->getStyle('A9:L9')->getFont()->setBold(true);
		//merge cell A1 until D1
		$this->excel->getActiveSheet()->mergeCells('A2:L2');
		$this->excel->getActiveSheet()->mergeCells('A3:L3');
		$this->excel->getActiveSheet()->mergeCells('A4:L4');
		$this->excel->getActiveSheet()->mergeCells('A5:L5');
		$this->excel->getActiveSheet()->mergeCells('A6:L6');

		//set cell A1 content with some text
		$this->excel->getActiveSheet()->setCellValue('A2', 'TANDA TERIMA TUNJANGAN KINERJA PEGAWAI ');
		$this->excel->getActiveSheet()->setCellValue('A3', 'KEMENTERIAN HUKUM DAN HAM R.I');
		$this->excel->getActiveSheet()->setCellValue('A4', 'KANTOR IMIGRASI KELAS I JAKARTA UTARA');
		$this->excel->getActiveSheet()->setCellValue('A6', 'Absensi : ' . $this->_data['periode']);

		$this->excel->getActiveSheet()->setCellValue('A8', 'NO.');
		$this->excel->getActiveSheet()->setCellValue('B8', 'NAMA/NIP');
		$this->excel->getActiveSheet()->setCellValue('C8', 'GOL');
		$this->excel->getActiveSheet()->setCellValue('D8', 'JABATAN');
		$this->excel->getActiveSheet()->setCellValue('E8', 'GRADE');
		$this->excel->getActiveSheet()->setCellValue('F8', 'BESARAN TUNJANGAN');
		$this->excel->getActiveSheet()->setCellValue('G8', 'TUNJ. PPH 21');
		$this->excel->getActiveSheet()->setCellValue('H8', 'BRUTO');
		$this->excel->getActiveSheet()->setCellValue('I8', 'POT.PPH 21');
		$this->excel->getActiveSheet()->setCellValue('J8', 'FAKTOR PENGURANG');
		$this->excel->getActiveSheet()->setCellValue('K8', 'NETTO');
		$this->excel->getActiveSheet()->setCellValue('L8', 'TANDA TANGAN');

		$this->excel->getActiveSheet()->setCellValue('A9', '1');
		$this->excel->getActiveSheet()->setCellValue('B9', '2');
		$this->excel->getActiveSheet()->setCellValue('C9', '3');
		$this->excel->getActiveSheet()->setCellValue('D9', '4');
		$this->excel->getActiveSheet()->setCellValue('E9', '5');
		$this->excel->getActiveSheet()->setCellValue('F9', '6');
		$this->excel->getActiveSheet()->setCellValue('G9', '7 ( 6*....% )');
		$this->excel->getActiveSheet()->setCellValue('H9', '8 ( 6+7 )');
		$this->excel->getActiveSheet()->setCellValue('I9', '9 ( 6*....% )');
		$this->excel->getActiveSheet()->setCellValue('J9', '10');
		$this->excel->getActiveSheet()->setCellValue('K9', '11 ( 8 - 9 - 10 )');
		$this->excel->getActiveSheet()->setCellValue('L9', '12');

		$cnt_row = 10;
		$no = 1;
		$total_besaran_tunjangan    = 0;
        $total_tunjangan_pph21      = 0;
        $total_bruto                = 0;
        $total_potongan_pph21       = 0;
        $total_faktor_pengurang     = 0;
        $total_netto                = 0;

		foreach ($this->_data['result'] as $val) {
			$this->excel->getActiveSheet()->getStyle(('B'.$cnt_row))->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_LEFT);
			$this->excel->getActiveSheet()->getStyle(('F'.$cnt_row))->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);
			$this->excel->getActiveSheet()->getStyle(('G'.$cnt_row))->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);
			$this->excel->getActiveSheet()->getStyle(('H'.$cnt_row))->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);
			$this->excel->getActiveSheet()->getStyle(('I'.$cnt_row))->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);
			$this->excel->getActiveSheet()->getStyle(('J'.$cnt_row))->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);
			$this->excel->getActiveSheet()->getStyle(('K'.$cnt_row))->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);

			$this->excel->getActiveSheet()->getStyle(('B'.$cnt_row))->getAlignment()->setWrapText(true);

			$besaran_tunjangan  = $val['tunjangan'];
            $tunjangan_pph21    = $potongan_pph21  = get_pph21($besaran_tunjangan);
            $bruto              = $besaran_tunjangan + $tunjangan_pph21;
            $faktor_pengurang   = !empty($this->_data['potongan'][$val['id_karyawan']]) ? $this->_data['potongan'][$val['id_karyawan']] : 0;
            $netto              = !empty($this->_data['potongan'][$val['id_karyawan']]) ? ($val['tunjangan'] - $this->_data['potongan'][$val['id_karyawan']]) : $val['tunjangan'];

            $total_besaran_tunjangan    += $besaran_tunjangan;
            $total_tunjangan_pph21      += $tunjangan_pph21;
            $total_bruto                += $bruto;
            $total_potongan_pph21       += $potongan_pph21;
            $total_faktor_pengurang     += $faktor_pengurang;
            $total_netto                += $netto;

			$this->excel->getActiveSheet()->setCellValue(('A'.$cnt_row), $no);
			$this->excel->getActiveSheet()->setCellValue(('B'.$cnt_row), ($val['nama_lengkap'] . "\r NIP. " . $val['nip']));
			$this->excel->getActiveSheet()->setCellValue(('C'.$cnt_row), $val['nama_golongan']);
			$this->excel->getActiveSheet()->setCellValue(('D'.$cnt_row), $val['nama_jabatan']);
			$this->excel->getActiveSheet()->setCellValue(('E'.$cnt_row), $val['kelas_grade']);
			$this->excel->getActiveSheet()->setCellValue(('F'.$cnt_row), (!empty($besaran_tunjangan) ? (number_format($besaran_tunjangan, 0, ',', '.')) : '-'));
			$this->excel->getActiveSheet()->setCellValue(('G'.$cnt_row), (!empty($tunjangan_pph21) ? (number_format($tunjangan_pph21, 0, ',', '.')) : '-'));
			$this->excel->getActiveSheet()->setCellValue(('H'.$cnt_row), (!empty($bruto) ? (number_format($bruto, 0, ',', '.')) : '-'));
			$this->excel->getActiveSheet()->setCellValue(('I'.$cnt_row), (!empty($potongan_pph21) ? (number_format($potongan_pph21, 0, ',', '.')) : '-'));
			$this->excel->getActiveSheet()->setCellValue(('J'.$cnt_row), (!empty($faktor_pengurang) ? (number_format($faktor_pengurang, 0, ',', '.')) : '-'));
			$this->excel->getActiveSheet()->setCellValue(('K'.$cnt_row), (!empty($netto) ? (number_format($netto, 0, ',', '.')) : '-'));

			$cnt_row++;
			$no++;
		}

		$this->excel->getActiveSheet()->getStyle(('B'.$cnt_row))->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_LEFT);
		$this->excel->getActiveSheet()->getStyle(('F'.$cnt_row))->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);
		$this->excel->getActiveSheet()->getStyle(('G'.$cnt_row))->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);
		$this->excel->getActiveSheet()->getStyle(('H'.$cnt_row))->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);
		$this->excel->getActiveSheet()->getStyle(('I'.$cnt_row))->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);
		$this->excel->getActiveSheet()->getStyle(('J'.$cnt_row))->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);
		$this->excel->getActiveSheet()->getStyle(('K'.$cnt_row))->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);
		$this->excel->getActiveSheet()->getStyle('A'.$cnt_row.':L'.$cnt_row)->getFont()->setBold(true);

		$this->excel->getActiveSheet()->setCellValue(('A'.$cnt_row), 'Jumlah');
		$this->excel->getActiveSheet()->setCellValue(('F'.$cnt_row), (!empty($total_besaran_tunjangan) ? (number_format($total_besaran_tunjangan, 0, ',', '.')) : '-'));
		$this->excel->getActiveSheet()->setCellValue(('G'.$cnt_row), (!empty($total_tunjangan_pph21) ? (number_format($total_tunjangan_pph21, 0, ',', '.')) : '-'));
		$this->excel->getActiveSheet()->setCellValue(('H'.$cnt_row), (!empty($total_bruto) ? (number_format($total_bruto, 0, ',', '.')) : '-'));
		$this->excel->getActiveSheet()->setCellValue(('I'.$cnt_row), (!empty($total_potongan_pph21) ? (number_format($total_potongan_pph21, 0, ',', '.')) : '-'));
		$this->excel->getActiveSheet()->setCellValue(('J'.$cnt_row), (!empty($total_faktor_pengurang) ? (number_format($total_faktor_pengurang, 0, ',', '.')) : '-'));
		$this->excel->getActiveSheet()->setCellValue(('K'.$cnt_row), (!empty($total_netto) ? (number_format($total_netto, 0, ',', '.')) : '-'));

		//$this->excel->getActiveSheet()->getStyle('A1')->getFont()->setSize(20);

		$filename='report_tanda_terima_'.time().'.xls'; //save our workbook as this file name
		header('Content-Type: application/vnd.ms-excel'); //mime type
		header('Content-Disposition: attachment;filename="'.$filename.'"'); //tell browser what's the file name
		header('Cache-Control: max-age=0'); //no cache
		            
		//save it to Excel5 format (excel 2003 .XLS file), change this to 'Excel2007' (and adjust the filename extension, also the header mime type)
		//if you want to save it as .XLSX Excel 2007 format
		$objWriter = PHPExcel_IOFactory::createWriter($this->excel, 'Excel5');  
		//force user to download the Excel file without writing it to server's HD
		$objWriter->save('php://output');
	}

	private function get_netto_karyawan() {
		$strtotime_tanggal_awal 	= strtotime(($this->_data['txt_tanggal_awal'] . ' 00:00:00'));
		$strtotime_tanggal_akhir 	= strtotime(($this->_data['txt_tanggal_akhir'] . ' 23:59:00'));

		$res_potongan 		= $this->report->get_all_sanksipotongan();
		$res_potongan_masuk = $this->report->order_by('sp_menit_awal', 'DESC')->get_all_sanksipotonganmasuk();
		$res_gakmasuk 		= $this->report->where(array('abs_tanggal >=' => $strtotime_tanggal_awal, 'abs_tanggal <=' => $strtotime_tanggal_akhir))->get_all_gakmasuk();
		$res_gakmasukmesin 	= $this->report->where(array('abs_tanggal >=' => $strtotime_tanggal_awal, 'abs_tanggal <=' => $strtotime_tanggal_akhir))->get_all_gakmasukmesin();
		$res_masuk 			= $this->report->where(array('nDateTime >=' => $strtotime_tanggal_awal, 'nDateTime <=' => $strtotime_tanggal_akhir))->get_all_masuk();
		
		$this->_data['potongan'] = array();

		$history = array();
		
		foreach ($res_masuk as $val) {
			$history[$val['nDateTime']][$val['id_karyawan']] = 1;

			if(!empty($res_gakmasuk[$val['id_karyawan']][$val['nDateTime']])) continue;
			if(!empty($res_gakmasukmesin[$val['id_karyawan']][$val['nDateTime']]['MT'])) $val['nLateInTime'] = 0;
			if(!empty($res_gakmasukmesin[$val['id_karyawan']][$val['nDateTime']]['PC'])) $val['nEarlyOutTime'] = 0;

			if(empty($val['nLateInTime']) AND empty($val['nEarlyOutTime'])) continue;

			if(empty($this->_data['potongan'][$val['id_karyawan']])) {
				$this->_data['potongan'][$val['id_karyawan']] = $this->get_potongan_absensi($val, $res_potongan_masuk);
			} else {
				$this->_data['potongan'][$val['id_karyawan']] += $this->get_potongan_absensi($val, $res_potongan_masuk);
			}
		}

		//hitung potongan karyawan yg gak masuk, yang beralasan kecuali karyawan masuk terlambat n pulang cepat
		foreach ($res_gakmasuk as $vId) {
			foreach ($vId as $val) {
				foreach ($val as $vAkhir) {
					$history[$vAkhir['abs_tanggal']][$vAkhir['id_karyawan']] = 1;

					if(empty($this->_data['potongan'][$vAkhir['id_karyawan']])) {
						$this->_data['potongan'][$vAkhir['id_karyawan']] = round(($vAkhir['tunjangan'] / 100) * $res_potongan[$vAkhir['jp_kode']][$vAkhir['id_sanksi_potongan']]['persentase']);
					} else {
						$this->_data['potongan'][$vAkhir['id_karyawan']] += round(($vAkhir['tunjangan'] / 100) * $res_potongan[$vAkhir['jp_kode']][$vAkhir['id_sanksi_potongan']]['persentase']);
					}
				}
			}
		}

		//hitung potongan karyawan yg gak masuk hanya karyawan masuk terlambat n pulang cepat
		foreach ($res_gakmasukmesin as $vId) {
			foreach ($vId as $vax) {
				foreach ($vax as $val) {
					foreach ($val as $vAkhir) {
						$history[$vAkhir['abs_tanggal']][$vAkhir['id_karyawan']] = 1;

						if(empty($this->_data['potongan'][$vAkhir['id_karyawan']])) {
							$this->_data['potongan'][$vAkhir['id_karyawan']] = round(($vAkhir['tunjangan'] / 100) * $res_potongan[$vAkhir['jp_kode']][$vAkhir['id_sanksi_potongan']]['persentase']);
						} else {
							$this->_data['potongan'][$vAkhir['id_karyawan']] += round(($vAkhir['tunjangan'] / 100) * $res_potongan[$vAkhir['jp_kode']][$vAkhir['id_sanksi_potongan']]['persentase']);
						}
					}
				}
			}
		}

		//hitung potongan karyawan yg gak masuk yang gak beralasan
		if(!empty($history)) {
			foreach ($this->_data['result'] as $key => $val) {
				foreach ($history as $kHistory => $vHistory) {
					if(!empty($history[$kHistory][$val['id_karyawan']])) continue;

					if(empty($this->_data['potongan'][$val['id_karyawan']])) {
						$this->_data['potongan'][$val['id_karyawan']] = round(($val['tunjangan'] / 100) * $res_potongan['TM'][1]['persentase']);
					} else {
						$this->_data['potongan'][$val['id_karyawan']] += round(($val['tunjangan'] / 100) * $res_potongan['TM'][1]['persentase']);
					}
				}
			}
		}
	}

	private function get_potongan_absensi($val, $res_potongan_masuk) {
		$potongan 	= 0;
		if($val['nLateInTime'] > 0) {
			foreach ($res_potongan_masuk['MT'][0] as $value) {
				if($val['nLateInTime'] >= $value['sp_menit_awal']) {
					$persentase = $value['persentase'];
					break;
				}
			}
			$potongan += round(($val['tunjangan'] / 100) * $persentase);
		}
		if($val['nEarlyOutTime'] > 0) {
			foreach ($res_potongan_masuk['PC'][0] as $value) {
				if($val['nEarlyOutTime'] >= $value['sp_menit_awal']) {
					$persentase = $value['persentase'];
					break;
				}
			}
			$potongan += round(($val['tunjangan'] / 100) * $persentase);
		}
		return $potongan;
	}

	function do_print() {
		$this->do_submit();

		$this->template->load('template_print/main_landscape', 'print', $this->_data);
	}
}

?>