<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Rekapkeb extends MY_Report {

	function __construct(){
		parent::__construct();

		if(!$this->session->userdata('admin_id')) {
			redirect('backend_login/login');
			exit();
		}

		$this->load->model('report_model', 'report');
	}
	
	function index() {
		if(!empty($_GET['txt_tanggal_awal']) AND !empty($_GET['txt_tanggal_akhir'])) {
			$this->do_submit();
		}

		$this->template->set('title', 'Rekap Keb');
		$this->template->set('assets', $this->_data['assets']);
		$this->template->load('template_report/main', 'lists', $this->_data);
	}

	private function do_submit() {
		$this->_data['txt_tanggal_awal'] 	= $_GET['txt_tanggal_awal'];
		$this->_data['txt_tanggal_akhir'] 	= $_GET['txt_tanggal_akhir'];
		$this->_data['txt_sisa'] 			= !empty($_GET['txt_sisa']) ? $_GET['txt_sisa'] : 0;

		$strtotime_tanggal_awal 	= strtotime($this->_data['txt_tanggal_awal']);
		$strtotime_tanggal_akhir 	= strtotime($this->_data['txt_tanggal_akhir']);

		if($strtotime_tanggal_awal > $strtotime_tanggal_akhir) {
			$this->_data['error'] = '<p>Tanggal akhir harus lebih sama dengan tanggal awal</p>';
			return false;
		}

		$this->_data['periode'] = date('d F Y', $strtotime_tanggal_awal) . ' s/d ' . date('d F Y', $strtotime_tanggal_akhir);
		$this->_data['result_grade'] = $this->report->get_all_grade();
		$this->_data['result'] = $this->report->get_all_karyawan();
		$this->get_netto_karyawan();

		$this->_data['kelas_grade'] = array();
		foreach ($this->_data['result'] as $val) {
			if(empty($this->_data['kelas_grade'][$val['kelas_grade']])) {
				$this->_data['kelas_grade'][$val['kelas_grade']] = 1;
			} else {
				$this->_data['kelas_grade'][$val['kelas_grade']] += 1;
			}
		}
	}

	function export_excel() {
		$this->do_submit();

		//load our new PHPExcel library
		$this->load->library('excel');
		//activate worksheet number 1
		$this->excel->setActiveSheetIndex(0);
		//name the worksheet
		$this->excel->getActiveSheet()->setTitle('Rekap Keb');

		$this->excel->getDefaultStyle()->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);

		$this->excel->getActiveSheet()->getColumnDimension('A')->setWidth(30);
		$this->excel->getActiveSheet()->getColumnDimension('B')->setWidth(30);
		$this->excel->getActiveSheet()->getColumnDimension('C')->setWidth(30);
		$this->excel->getActiveSheet()->getColumnDimension('D')->setWidth(30);
		$this->excel->getActiveSheet()->getColumnDimension('E')->setWidth(30);
		$this->excel->getActiveSheet()->getColumnDimension('F')->setWidth(30);
		$this->excel->getActiveSheet()->getColumnDimension('G')->setWidth(30);
		$this->excel->getActiveSheet()->getColumnDimension('H')->setWidth(30);
		$this->excel->getActiveSheet()->getColumnDimension('I')->setWidth(30);
		$this->excel->getActiveSheet()->getColumnDimension('J')->setWidth(30);

		//make the font become bold
		$this->excel->getActiveSheet()->getStyle('A2')->getFont()->setBold(true);
		$this->excel->getActiveSheet()->getStyle('A3')->getFont()->setBold(true);
		$this->excel->getActiveSheet()->getStyle('A4')->getFont()->setBold(true);

		$this->excel->getActiveSheet()->getStyle('A6:J6')->getFont()->setBold(true);
		$this->excel->getActiveSheet()->getStyle('A7:J7')->getFont()->setBold(true);
		//merge cell A1 until D1
		$this->excel->getActiveSheet()->mergeCells('A2:J2');
		$this->excel->getActiveSheet()->mergeCells('A3:J3');
		$this->excel->getActiveSheet()->mergeCells('A4:J4');

		//set cell A1 content with some text
		$this->excel->getActiveSheet()->setCellValue('A2', 'REKAPITULASI KEBUTUHAN PEMBAYARAN TUNJANGAN KINERJA');
		$this->excel->getActiveSheet()->setCellValue('A3', 'KANTOR IMIGRASI KELAS I JAKARTA UTARA');
		$this->excel->getActiveSheet()->setCellValue('A4', 'Tanggal ' . $this->_data['periode']);

		$this->excel->getActiveSheet()->setCellValue('A6', 'NO.');
		$this->excel->getActiveSheet()->setCellValue('B6', 'UPT/KANTOR');
		$this->excel->getActiveSheet()->setCellValue('C6', 'KELAS JABATAN / GRADE');
		$this->excel->getActiveSheet()->setCellValue('D6', 'JUMLAH PEGAWAI');
		$this->excel->getActiveSheet()->setCellValue('E6', 'BESAR TUNJANGAN KINERJA');
		$this->excel->getActiveSheet()->setCellValue('F6', 'JUMLAH TUNJANGAN KINERJA');
		$this->excel->getActiveSheet()->setCellValue('G6', 'PAJAK');
		$this->excel->getActiveSheet()->setCellValue('H6', 'FAKTOR PENGURANG');
		$this->excel->getActiveSheet()->setCellValue('I6', 'KEKURANGAN BULAN LALU');
		$this->excel->getActiveSheet()->setCellValue('J6', 'TOTAL KEBUTUHAN');

		$this->excel->getActiveSheet()->setCellValue('A7', '1');
		$this->excel->getActiveSheet()->setCellValue('B7', '2');
		$this->excel->getActiveSheet()->setCellValue('C7', '3');
		$this->excel->getActiveSheet()->setCellValue('D7', '4');
		$this->excel->getActiveSheet()->setCellValue('E7', '5');
		$this->excel->getActiveSheet()->setCellValue('F7', '6=(4X5)');
		$this->excel->getActiveSheet()->setCellValue('G7', '7');
		$this->excel->getActiveSheet()->setCellValue('H7', '8');
		$this->excel->getActiveSheet()->setCellValue('I7', '9');
		$this->excel->getActiveSheet()->setCellValue('J7', '10=(6-8+9)');

		$cnt_row = 8;
		$no = 1;
		$total_pegawai      = 0;
        $total_tunjangan    = 0;
        $total_pajak        = 0;
        $total_potongan     = 0;
        $total_kebutuhan    = 0;
        $sisa_bulan_lalu    = !empty($txt_sisa) ? $txt_sisa : 0;

        $show_upt_kantor = true;

		foreach ($this->_data['result_grade'] as $val) {
			$this->excel->getActiveSheet()->getStyle(('D'.$cnt_row))->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);
			$this->excel->getActiveSheet()->getStyle(('F'.$cnt_row))->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);
			$this->excel->getActiveSheet()->getStyle(('G'.$cnt_row))->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);
			$this->excel->getActiveSheet()->getStyle(('H'.$cnt_row))->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);
			$this->excel->getActiveSheet()->getStyle(('J'.$cnt_row))->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);

			$this->excel->getActiveSheet()->getStyle(('B'.$cnt_row))->getAlignment()->setWrapText(true);

			$jumlah_pegawai     = !empty($this->_data['kelas_grade'][$val['kelas_grade']]) ? $this->_data['kelas_grade'][$val['kelas_grade']] : 0;
            $jumlah_tunjangan   = $jumlah_pegawai * $val['tunjangan'];
            $pajak              = get_pph21($jumlah_tunjangan);
            $potongan_x         = !empty($this->_data['potongan'][$val['kelas_grade']]) ? $this->_data['potongan'][$val['kelas_grade']] : 0;
            $jumlah_kebutuhan   = $jumlah_tunjangan - $potongan_x;

            $total_pegawai      += $jumlah_pegawai;
            $total_tunjangan    += $jumlah_tunjangan;
            $total_pajak        += $pajak;
            $total_potongan     += $potongan_x;
            $total_kebutuhan    += $jumlah_kebutuhan;

			$this->excel->getActiveSheet()->setCellValue(('A'.$cnt_row), $no);
			if($show_upt_kantor) {
				$this->excel->getActiveSheet()->setCellValue(('B'.$cnt_row), "KANTOR IMIGRASI \n KELAS I JAKARTA UTARA");
				$show_upt_kantor = false;
			}
			$this->excel->getActiveSheet()->setCellValue(('C'.$cnt_row), $val['kelas_grade']);
			$this->excel->getActiveSheet()->setCellValue(('D'.$cnt_row), (!empty($jumlah_pegawai) ? $jumlah_pegawai : '-'));
			$this->excel->getActiveSheet()->setCellValue(('E'.$cnt_row), (!empty($val['tunjangan']) ? (number_format($val['tunjangan'], 0, ',', '.')) : '-'));
			$this->excel->getActiveSheet()->setCellValue(('F'.$cnt_row), (!empty($jumlah_tunjangan) ? (number_format($jumlah_tunjangan, 0, ',', '.')) : '-'));
			$this->excel->getActiveSheet()->setCellValue(('G'.$cnt_row), (!empty($pajak) ? (number_format($pajak, 0, ',', '.')) : '-'));
			$this->excel->getActiveSheet()->setCellValue(('H'.$cnt_row), (!empty($potongan_x) ? (number_format($potongan_x, 0, ',', '.')) : '-'));
			$this->excel->getActiveSheet()->setCellValue(('I'.$cnt_row), (!empty($netto) ? (number_format($netto, 0, ',', '.')) : '-'));
			$this->excel->getActiveSheet()->setCellValue(('J'.$cnt_row), (!empty($jumlah_kebutuhan) ? (number_format($jumlah_kebutuhan, 0, ',', '.')) : '-'));

			$cnt_row++;
			$no++;
		}

		$this->excel->getActiveSheet()->getStyle(('D'.$cnt_row))->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);
		$this->excel->getActiveSheet()->getStyle(('F'.$cnt_row))->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);
		$this->excel->getActiveSheet()->getStyle(('G'.$cnt_row))->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);
		$this->excel->getActiveSheet()->getStyle(('H'.$cnt_row))->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);
		$this->excel->getActiveSheet()->getStyle(('J'.$cnt_row))->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);
		$this->excel->getActiveSheet()->getStyle('A'.$cnt_row.':J'.($cnt_row + 2))->getFont()->setBold(true);

		$this->excel->getActiveSheet()->setCellValue(('A'.$cnt_row), 'Jumlah');
		$this->excel->getActiveSheet()->setCellValue(('D'.$cnt_row), (!empty($total_pegawai) ? (number_format($total_pegawai, 0, ',', '.')) : '-'));
		$this->excel->getActiveSheet()->setCellValue(('F'.$cnt_row), (!empty($total_tunjangan) ? (number_format($total_tunjangan, 0, ',', '.')) : '-'));
		$this->excel->getActiveSheet()->setCellValue(('G'.$cnt_row), (!empty($total_pajak) ? (number_format($total_pajak, 0, ',', '.')) : '-'));
		$this->excel->getActiveSheet()->setCellValue(('H'.$cnt_row), (!empty($total_potongan) ? (number_format($total_potongan, 0, ',', '.')) : '-'));
		$this->excel->getActiveSheet()->setCellValue(('J'.$cnt_row), (!empty($total_kebutuhan) ? (number_format($total_kebutuhan, 0, ',', '.')) : '-'));

		$this->excel->getActiveSheet()->mergeCells('B8:B' . (8 + count($this->_data['result_grade']) - 1));

		$this->excel->getActiveSheet()->setCellValue(('A'.($cnt_row + 1)), 'Sisa Dana Bulan Lalu');
		$this->excel->getActiveSheet()->setCellValue(('J'.($cnt_row + 1)), (!empty($this->_data['txt_sisa']) ? (number_format($this->_data['txt_sisa'], 0, ',', '.')) : '-'));
		$this->excel->getActiveSheet()->getStyle(('J'.($cnt_row + 1)))->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);

		$total_semua = $total_kebutuhan - $this->_data['txt_sisa'];

		$this->excel->getActiveSheet()->setCellValue(('A'.($cnt_row + 2)), 'Total Kebutuhan');
		$this->excel->getActiveSheet()->setCellValue(('J'.($cnt_row + 2)), (!empty($total_semua) ? (number_format($total_semua, 0, ',', '.')) : '-'));
		$this->excel->getActiveSheet()->getStyle(('J'.($cnt_row + 2)))->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);

		//$this->excel->getActiveSheet()->getStyle('A1')->getFont()->setSize(20);

		$filename='report_rekap_keb_'.time().'.xls'; //save our workbook as this file name
		header('Content-Type: application/vnd.ms-excel'); //mime type
		header('Content-Disposition: attachment;filename="'.$filename.'"'); //tell browser what's the file name
		header('Cache-Control: max-age=0'); //no cache
		            
		//save it to Excel5 format (excel 2003 .XLS file), change this to 'Excel2007' (and adjust the filename extension, also the header mime type)
		//if you want to save it as .XLSX Excel 2007 format
		$objWriter = PHPExcel_IOFactory::createWriter($this->excel, 'Excel5');  
		//force user to download the Excel file without writing it to server's HD
		$objWriter->save('php://output');
	}

	private function get_netto_karyawan() {
		$strtotime_tanggal_awal 	= strtotime(($this->_data['txt_tanggal_awal'] . ' 00:00:00'));
		$strtotime_tanggal_akhir 	= strtotime(($this->_data['txt_tanggal_akhir'] . ' 23:59:00'));

		$res_potongan 		= $this->report->get_all_sanksipotongan();
		$res_potongan_masuk = $this->report->order_by('sp_menit_awal', 'DESC')->get_all_sanksipotonganmasuk();
		$res_gakmasuk 		= $this->report->where(array('abs_tanggal >=' => $strtotime_tanggal_awal, 'abs_tanggal <=' => $strtotime_tanggal_akhir))->get_all_gakmasuk();
		$res_gakmasukmesin 	= $this->report->where(array('abs_tanggal >=' => $strtotime_tanggal_awal, 'abs_tanggal <=' => $strtotime_tanggal_akhir))->get_all_gakmasukmesin();
		$res_masuk 			= $this->report->where(array('nDateTime >=' => $strtotime_tanggal_awal, 'nDateTime <=' => $strtotime_tanggal_akhir))->get_all_masuk();
		
		$this->_data['potongan'] = array();

		$history = array();
		
		foreach ($res_masuk as $val) {
			$history[$val['nDateTime']][$val['id_karyawan']] = 1;

			if(!empty($res_gakmasuk[$val['id_karyawan']][$val['nDateTime']])) continue;
			if(!empty($res_gakmasukmesin[$val['id_karyawan']][$val['nDateTime']]['MT'])) $val['nLateInTime'] = 0;
			if(!empty($res_gakmasukmesin[$val['id_karyawan']][$val['nDateTime']]['PC'])) $val['nEarlyOutTime'] = 0;

			if(empty($val['nLateInTime']) AND empty($val['nEarlyOutTime'])) continue;

			if(empty($this->_data['potongan'][$val['kelas_grade']])) {
				$this->_data['potongan'][$val['kelas_grade']] = $this->get_potongan_absensi($val, $res_potongan_masuk);
			} else {
				$this->_data['potongan'][$val['kelas_grade']] += $this->get_potongan_absensi($val, $res_potongan_masuk);
			}
		}

		//hitung potongan karyawan yg gak masuk, yang beralasan kecuali karyawan masuk terlambat n pulang cepat
		foreach ($res_gakmasuk as $vId) {
			foreach ($vId as $val) {
				foreach ($val as $vAkhir) {
					$history[$vAkhir['abs_tanggal']][$vAkhir['id_karyawan']] = 1;

					if(empty($this->_data['potongan'][$vAkhir['kelas_grade']])) {
						$this->_data['potongan'][$vAkhir['kelas_grade']] = round(($vAkhir['tunjangan'] / 100) * $res_potongan[$vAkhir['jp_kode']][$vAkhir['id_sanksi_potongan']]['persentase']);
					} else {
						$this->_data['potongan'][$vAkhir['kelas_grade']] += round(($vAkhir['tunjangan'] / 100) * $res_potongan[$vAkhir['jp_kode']][$vAkhir['id_sanksi_potongan']]['persentase']);
					}
				}
			}
		}

		//hitung potongan karyawan yg gak masuk hanya karyawan masuk terlambat n pulang cepat
		foreach ($res_gakmasukmesin as $vId) {
			foreach ($vId as $vax) {
				foreach ($vax as $val) {
					foreach ($val as $vAkhir) {
						$history[$vAkhir['abs_tanggal']][$vAkhir['id_karyawan']] = 1;

						if(empty($this->_data['potongan'][$vAkhir['kelas_grade']])) {
							$this->_data['potongan'][$vAkhir['kelas_grade']] = round(($vAkhir['tunjangan'] / 100) * $res_potongan[$vAkhir['jp_kode']][$vAkhir['id_sanksi_potongan']]['persentase']);
						} else {
							$this->_data['potongan'][$vAkhir['kelas_grade']] += round(($vAkhir['tunjangan'] / 100) * $res_potongan[$vAkhir['jp_kode']][$vAkhir['id_sanksi_potongan']]['persentase']);
						}
					}
				}
			}
		}

		//hitung potongan karyawan yg gak masuk yang gak beralasan
		if(!empty($history)) {
			foreach ($this->_data['result'] as $key => $val) {
				foreach ($history as $kHistory => $vHistory) {
					if(!empty($history[$kHistory][$val['id_karyawan']])) continue;

					if(empty($this->_data['potongan'][$val['kelas_grade']])) {
						$this->_data['potongan'][$val['kelas_grade']] = round(($val['tunjangan'] / 100) * $res_potongan['TM'][1]['persentase']);
					} else {
						$this->_data['potongan'][$val['kelas_grade']] += round(($val['tunjangan'] / 100) * $res_potongan['TM'][1]['persentase']);
					}
				}
			}
		}
	}

	private function get_potongan_absensi($val, $res_potongan_masuk) {
		$potongan 	= 0;
		if($val['nLateInTime'] > 0) {
			foreach ($res_potongan_masuk['MT'][0] as $value) {
				if($val['nLateInTime'] >= $value['sp_menit_awal']) {
					$persentase = $value['persentase'];
					break;
				}
			}
			$potongan += round(($val['tunjangan'] / 100) * $persentase);
		}
		if($val['nEarlyOutTime'] > 0) {
			foreach ($res_potongan_masuk['PC'][0] as $value) {
				if($val['nEarlyOutTime'] >= $value['sp_menit_awal']) {
					$persentase = $value['persentase'];
					break;
				}
			}
			$potongan += round(($val['tunjangan'] / 100) * $persentase);
		}
		return $potongan;
	}

	function do_print() {
		$this->do_submit();

		$this->template->load('template_print/main_portrait', 'print', $this->_data);
	}
}

?>