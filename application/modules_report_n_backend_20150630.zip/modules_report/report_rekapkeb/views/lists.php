<div class="row page-header">
    <h3>Report Rekap Keb</h3>
</div>

<div class="row">
    <?php if(isset($error)) : ?>
        <div class="alert alert-danger">
            <?php echo $error; ?>
        </div>
    <?php endif; ?>
    <form class="form-inline" role="form" action="<?php echo site_url('report/rekap-keb'); ?>">
        <div class="form-group">
            <label for="txt_sisa">Sisa:</label>
            <input class="form-control" id="txt_sisa" name="txt_sisa" value="<?php echo (!empty($txt_sisa) ? $txt_sisa : ''); ?>">
        </div>
        <div class="form-group">
            <label for="txt_tanggal_awal">Tanggal Awal:</label>
            <input class="datepicker form-control" id="txt_tanggal_awal" name="txt_tanggal_awal" value="<?php echo (!empty($txt_tanggal_awal) ? $txt_tanggal_awal : ''); ?>">
        </div>
        <div class="form-group">
            <label for="txt_tanggal_akhir">Tanggal Akhir:</label>
            <input class="datepicker form-control" id="txt_tanggal_akhir" name="txt_tanggal_akhir" value="<?php echo (!empty($txt_tanggal_akhir) ? $txt_tanggal_akhir : ''); ?>">
        </div>
        <button type="submit" class="btn btn-default">Submit</button>
        <?php if(!empty($periode)): ?>
        <a href="<?php echo site_url('report/rekap-keb/export?txt_tanggal_awal=' . $txt_tanggal_awal . '&txt_tanggal_akhir=' . $txt_tanggal_akhir . '&txt_sisa=' . $txt_sisa); ?>" class="btn btn-success"><span class="glyphicon glyphicon-star" aria-hidden="true"></span> Export Excel</a> <a target="_blank" href="<?php echo site_url('report/rekap-keb/print?txt_tanggal_awal=' . $txt_tanggal_awal . '&txt_tanggal_akhir=' . $txt_tanggal_akhir . '&txt_sisa=' . $txt_sisa); ?>" class="btn btn-primary"><span class="glyphicon glyphicon-star" aria-hidden="true"></span> Print</a>
        <?php endif; ?>
    </form>
</div>

<?php if(!empty($periode)): ?>
<div class="row report">
    <p>REKAPITULASI KEBUTUHAN PEMBAYARAN TUNJANGAN KINERJA<br />KANTOR IMIGRASI KELAS I JAKARTA UTARA<br />UNTUK TANGGAL : <?php echo $periode; ?></p>
    <div class="table-responsive">
        <table class="table table-striped table-bordered table-condensed">
            <thead class="gray">
                <tr>
                    <th>NO.</th>
                    <th>UPT KANTOR</th>
                    <th>KELAS JABATAN GRADE</th>
                    <th>JUMLAH PEGAWAI</th>
                    <th>BESARNYA TUNJANGAN KINERJA</th>
                    <th>JUMLAH TUNJANGAN KINERJA</th>
                    <th>PAJAK</th>
                    <th>FAKTOR PENGURANG</th>
                    <th>KEKURANGAN BULAN LALU 2014</th>
                    <th>TOTAL KEBUTUHAN</th>
                </tr>
                <tr>
                    <th>1</th>
                    <th>2</th>
                    <th>3</th>
                    <th>4</th>
                    <th>5</th>
                    <th>6=(4X5)</th>
                    <th>7</th>
                    <th>8</th>
                    <th>9</th>
                    <th>10=(6-8+9)</th>
                </tr>
            </thead>
            <tbody>
                <?php
                    $total_pegawai      = 0;
                    $total_tunjangan    = 0;
                    $total_pajak        = 0;
                    $total_potongan     = 0;
                    $total_kebutuhan    = 0;
                    $sisa_bulan_lalu    = !empty($txt_sisa) ? $txt_sisa : 0;
                ?>
                <?php foreach($result_grade as $key => $val) : ?>
                <?php
                    $jumlah_pegawai     = !empty($kelas_grade[$val['kelas_grade']]) ? $kelas_grade[$val['kelas_grade']] : 0;
                    $jumlah_tunjangan   = $jumlah_pegawai * $val['tunjangan'];
                    $pajak              = get_pph21($jumlah_tunjangan);
                    $potongan_x         = !empty($potongan[$val['kelas_grade']]) ? $potongan[$val['kelas_grade']] : 0;
                    $jumlah_kebutuhan   = $jumlah_tunjangan - $potongan_x;

                    $total_pegawai      += $jumlah_pegawai;
                    $total_tunjangan    += $jumlah_tunjangan;
                    $total_pajak        += $pajak;
                    $total_potongan     += $potongan_x;
                    $total_kebutuhan    += $jumlah_kebutuhan;
                ?>
                <?php if($key == 0) : ?>
                <tr>
                    <td rowspan="<?php echo count($result_grade); ?>">1</td>
                    <td rowspan="<?php echo count($result_grade); ?>">KANTOR IMIGRASI KELAS I JAKARTA UTARA</td>
                    <td><?php echo $val['kelas_grade']; ?></td>
                    <td><?php echo (!empty($jumlah_pegawai) ? $jumlah_pegawai : '-'); ?></td>
                    <td><div style="text-align:right;"><?php echo (!empty($val['tunjangan']) ? number_format($val['tunjangan'], 0 , ',', '.') : '-'); ?></div></td>
                    <td><div style="text-align:right;"><?php echo (!empty($jumlah_tunjangan) ? number_format($jumlah_tunjangan, 0 , ',', '.') : '-'); ?></div></td>
                    <td><div style="text-align:right;"><?php echo (!empty($pajak) ? number_format($pajak, 0 , ',', '.') : '-'); ?></div></td>
                    <td><div style="text-align:right;"><?php echo (!empty($potongan_x) ? number_format($potongan_x, 0 , ',', '.') : '-'); ?></div></td>
                    <td></td>
                    <td><div style="text-align:right;"><?php echo (!empty($jumlah_kebutuhan) ? number_format($jumlah_kebutuhan, 0 , ',', '.') : '-'); ?></div></td>
                </tr>
                <?php else : ?>
                <tr>
                    <td><?php echo $val['kelas_grade']; ?></td>
                    <td><?php echo (!empty($jumlah_pegawai) ? $jumlah_pegawai : '-'); ?></td>
                    <td><div style="text-align:right;"><?php echo (!empty($val['tunjangan']) ? number_format($val['tunjangan'], 0 , ',', '.') : '-'); ?></div></td>
                    <td><div style="text-align:right;"><?php echo (!empty($jumlah_tunjangan) ? number_format($jumlah_tunjangan, 0 , ',', '.') : '-'); ?></div></td>
                    <td><div style="text-align:right;"><?php echo (!empty($pajak) ? number_format($pajak, 0 , ',', '.') : '-'); ?></div></td>
                    <td><div style="text-align:right;"><?php echo (!empty($potongan_x) ? number_format($potongan_x, 0 , ',', '.') : '-'); ?></div></td>
                    <td></td>
                    <td><div style="text-align:right;"><?php echo (!empty($jumlah_kebutuhan) ? number_format($jumlah_kebutuhan, 0 , ',', '.') : '-'); ?></div></td>
                </tr>
                <?php endif; ?>
                <?php endforeach; ?>
                <tr class="jumlah">
                    <td colspan="2">JUMLAH</td>
                    <td></td>
                    <td><?php echo (!empty($total_pegawai) ? $total_pegawai : '-'); ?></td>
                    <td></td>
                    <td><div style="text-align:right;"><?php echo (!empty($total_tunjangan) ? number_format($total_tunjangan, 0 , ',', '.') : '-'); ?></div></td>
                    <td><div style="text-align:right;"><?php echo (!empty($total_pajak) ? number_format($total_pajak, 0 , ',', '.') : '-'); ?></div></td>
                    <td><div style="text-align:right;"><?php echo (!empty($total_potongan) ? number_format($total_potongan, 0 , ',', '.') : '-'); ?></div></td>
                    <td></td>
                    <td><div style="text-align:right;"><?php echo (!empty($total_kebutuhan) ? number_format($total_kebutuhan, 0 , ',', '.') : '-'); ?></div></td>
                </tr>
                <tr class="jumlah">
                    <td colspan="9"><div style="text-align:left;">Sisa Dana Bulan Lalu</div></td>
                    <td><div style="text-align:right;"><?php echo (!empty($sisa_bulan_lalu) ? number_format($sisa_bulan_lalu, 0 , ',', '.') : '-'); ?></div></td>
                </tr>
                <?php
                    $total_semua = $total_kebutuhan - $sisa_bulan_lalu;
                ?>
                <tr class="jumlah">
                    <td colspan="9"><div style="text-align:left;">Total Kebutuhan</div></td>
                    <td><div style="text-align:right;"><?php echo (!empty($total_semua) ? number_format($total_semua, 0 , ',', '.') : '-'); ?></div></td>
                </tr>
            </tbody>
        </table>
    </div>
</div>
<?php endif; ?>