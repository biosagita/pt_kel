<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Rekaplpj extends MY_Report {

	function __construct(){
		parent::__construct();

		if(!$this->session->userdata('admin_id')) {
			redirect('backend_login/login');
			exit();
		}

		$this->load->model('report_model', 'report');
	}
	
	function index() {
		if(!empty($_GET['txt_tanggal_awal']) AND !empty($_GET['txt_tanggal_akhir'])) {
			$this->do_submit();
		}

		$this->template->set('title', 'Rekap LPJ');
		$this->template->set('assets', $this->_data['assets']);
		$this->template->load('template_report/main', 'lists', $this->_data);
	}

	private function do_submit() {
		$this->_data['txt_tanggal_awal'] 	= $_GET['txt_tanggal_awal'];
		$this->_data['txt_tanggal_akhir'] 	= $_GET['txt_tanggal_akhir'];
		$this->_data['txt_saldo_awal'] 		= !empty($_GET['txt_saldo_awal']) ? $_GET['txt_saldo_awal'] : 0;
		$this->_data['txt_transfer_setjen'] = !empty($_GET['txt_transfer_setjen']) ? $_GET['txt_transfer_setjen'] : 0;

		$strtotime_tanggal_awal 	= strtotime($this->_data['txt_tanggal_awal']);
		$strtotime_tanggal_akhir 	= strtotime($this->_data['txt_tanggal_akhir']);

		if($strtotime_tanggal_awal > $strtotime_tanggal_akhir) {
			$this->_data['error'] = '<p>Tanggal akhir harus lebih sama dengan tanggal awal</p>';
			return false;
		}

		$this->_data['periode'] = date('d F Y', $strtotime_tanggal_awal) . ' s/d ' . date('d F Y', $strtotime_tanggal_akhir);
		$this->_data['result_grade'] = $this->report->get_all_grade();
		$this->_data['result'] = $this->report->get_all_karyawan();
		$this->get_netto_karyawan();

		$this->_data['kelas_grade'] = array();
		$this->_data['total_tunjangan'] = 0;
		$this->_data['jumlah_pegawai'] 	= 0;
		foreach ($this->_data['result'] as $val) {
			if(empty($this->_data['kelas_grade'][$val['kelas_grade']])) {
				$this->_data['kelas_grade'][$val['kelas_grade']] = 1;
			} else {
				$this->_data['kelas_grade'][$val['kelas_grade']] += 1;
			}

			$this->_data['total_tunjangan'] += $val['tunjangan'];
			$this->_data['jumlah_pegawai']++;
		}

		$this->_data['total_karyawan'] = !empty($this->_data['kelas_grade']) ? array_sum($this->_data['kelas_grade']) : 0;
		$this->_data['pajak'] = get_pph21($this->_data['total_tunjangan']);
		$this->_data['bruto'] = $this->_data['total_tunjangan'] + $this->_data['pajak'];
		$this->_data['total_potongan'] = !empty($this->_data['potongan']) ? array_sum($this->_data['potongan']) : 0;
		$this->_data['netto'] = $this->_data['bruto'] - ($this->_data['total_potongan'] + $this->_data['pajak']);
		$this->_data['total_kebutuhan'] = $this->_data['txt_saldo_awal'] + $this->_data['txt_transfer_setjen'];
		$this->_data['sisa_dana'] = $this->_data['total_kebutuhan'] - $this->_data['netto'];
	}

	function export_excel() {
		$this->do_submit();

		//load our new PHPExcel library
		$this->load->library('excel');
		//activate worksheet number 1
		$this->excel->setActiveSheetIndex(0);
		//name the worksheet
		$this->excel->getActiveSheet()->setTitle('Rekap LPJ');

		$this->excel->getDefaultStyle()->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);

		$this->excel->getActiveSheet()->getColumnDimension('A')->setWidth(30);
		$this->excel->getActiveSheet()->getColumnDimension('B')->setWidth(30);
		$this->excel->getActiveSheet()->getColumnDimension('C')->setWidth(30);
		$this->excel->getActiveSheet()->getColumnDimension('D')->setWidth(30);
		$this->excel->getActiveSheet()->getColumnDimension('E')->setWidth(30);
		$this->excel->getActiveSheet()->getColumnDimension('F')->setWidth(30);
		$this->excel->getActiveSheet()->getColumnDimension('G')->setWidth(30);
		$this->excel->getActiveSheet()->getColumnDimension('H')->setWidth(30);
		$this->excel->getActiveSheet()->getColumnDimension('I')->setWidth(30);
		$this->excel->getActiveSheet()->getColumnDimension('J')->setWidth(30);
		$this->excel->getActiveSheet()->getColumnDimension('K')->setWidth(30);
		$this->excel->getActiveSheet()->getColumnDimension('L')->setWidth(30);

		//make the font become bold
		$this->excel->getActiveSheet()->getStyle('A1')->getFont()->setBold(true);
		$this->excel->getActiveSheet()->getStyle('A2')->getFont()->setBold(true);
		$this->excel->getActiveSheet()->getStyle('A3')->getFont()->setBold(true);
		$this->excel->getActiveSheet()->getStyle('A5:L5')->getFont()->setBold(true);
		$this->excel->getActiveSheet()->getStyle('A6:L6')->getFont()->setBold(true);
		//merge cell A1 until D1
		$this->excel->getActiveSheet()->mergeCells('A1:L1');
		$this->excel->getActiveSheet()->mergeCells('A2:L2');
		$this->excel->getActiveSheet()->mergeCells('A3:L3');

		//set cell A1 content with some text
		$this->excel->getActiveSheet()->setCellValue('A1', 'REKAPITULASI LAPORAN PERTANGGUNG JAWABAN TUNJANGAN KINERJA (REVISI)');
		$this->excel->getActiveSheet()->setCellValue('A2', 'KANTOR IMIGRASI KELAS I JAKARTA UTARA');
		$this->excel->getActiveSheet()->setCellValue('A3', 'BERDASARKAN ABSEN TANGGAL : ' . $this->_data['periode']);

		$this->excel->getActiveSheet()->setCellValue('A5', 'NO.');
		$this->excel->getActiveSheet()->setCellValue('B5', 'NAMA KANTOR/UPT');
		$this->excel->getActiveSheet()->setCellValue('C5', 'SALDO AWAL');
		$this->excel->getActiveSheet()->setCellValue('D5', 'TRANSFER SETJEN');
		$this->excel->getActiveSheet()->setCellValue('E5', 'TOTAL KEBUTUHAN');

		$this->excel->getActiveSheet()->mergeCells('A5:A6');
		$this->excel->getActiveSheet()->mergeCells('B5:B6');
		$this->excel->getActiveSheet()->mergeCells('C5:C6');
		$this->excel->getActiveSheet()->mergeCells('D5:D6');
		$this->excel->getActiveSheet()->mergeCells('E5:E6');

		$this->excel->getActiveSheet()->setCellValue('F5', 'REALISASI');
		$this->excel->getActiveSheet()->mergeCells('F5:G5');
		$this->excel->getActiveSheet()->setCellValue('F6', 'TUNJANGAN KINERJA');
		$this->excel->getActiveSheet()->setCellValue('G6', 'PPh 21');

		$this->excel->getActiveSheet()->setCellValue('H5', 'BRUTO');
		$this->excel->getActiveSheet()->mergeCells('H5:H6');

		$this->excel->getActiveSheet()->setCellValue('I5', 'POTONGAN');
		$this->excel->getActiveSheet()->mergeCells('I5:J5');
		$this->excel->getActiveSheet()->setCellValue('I6', 'PPh 21');
		$this->excel->getActiveSheet()->setCellValue('J6', 'FAKTOR PENGURANG');

		$this->excel->getActiveSheet()->setCellValue('K5', 'NETTO');
		$this->excel->getActiveSheet()->mergeCells('K5:K6');

		$this->excel->getActiveSheet()->setCellValue('L5', 'SISA DANA/SALDO AKHIR');
		$this->excel->getActiveSheet()->mergeCells('L5:L6');

		$this->excel->getActiveSheet()->setCellValue('A7', '1');
		$this->excel->getActiveSheet()->setCellValue('B7', '2');
		$this->excel->getActiveSheet()->setCellValue('C7', '3');
		$this->excel->getActiveSheet()->setCellValue('D7', '4');
		$this->excel->getActiveSheet()->setCellValue('E7', '5=(3+4)');
		$this->excel->getActiveSheet()->setCellValue('F7', '6');
		$this->excel->getActiveSheet()->setCellValue('G7', '7');
		$this->excel->getActiveSheet()->setCellValue('H7', '8=(6+7)');
		$this->excel->getActiveSheet()->setCellValue('I7', '9');
		$this->excel->getActiveSheet()->setCellValue('J7', '10');
		$this->excel->getActiveSheet()->setCellValue('K7', '11=(8-9-10)');
		$this->excel->getActiveSheet()->setCellValue('L7', '12=(5-11)');

		$cnt_row = 8;
		$no = 1;
		$total = 0;

		$this->excel->getActiveSheet()->getStyle(('C'.$cnt_row))->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);
		$this->excel->getActiveSheet()->getStyle(('D'.$cnt_row))->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);
		$this->excel->getActiveSheet()->getStyle(('E'.$cnt_row))->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);
		$this->excel->getActiveSheet()->getStyle(('F'.$cnt_row))->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);
		$this->excel->getActiveSheet()->getStyle(('G'.$cnt_row))->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);
		$this->excel->getActiveSheet()->getStyle(('H'.$cnt_row))->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);
		$this->excel->getActiveSheet()->getStyle(('I'.$cnt_row))->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);
		$this->excel->getActiveSheet()->getStyle(('J'.$cnt_row))->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);
		$this->excel->getActiveSheet()->getStyle(('K'.$cnt_row))->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);
		$this->excel->getActiveSheet()->getStyle(('L'.$cnt_row))->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);

		$this->excel->getActiveSheet()->setCellValue(('A'.$cnt_row), $no);
		$this->excel->getActiveSheet()->setCellValue(('B'.$cnt_row), 'KANTOR IMIGRASI KELAS I JAKARTA UTARA');
		$this->excel->getActiveSheet()->setCellValue(('C'.$cnt_row), (!empty($this->_data['txt_saldo_awal']) ? (number_format($this->_data['txt_saldo_awal'], 0, ',', '.')) : '-'));
		$this->excel->getActiveSheet()->setCellValue(('D'.$cnt_row), (!empty($this->_data['txt_transfer_setjen']) ? (number_format($this->_data['txt_transfer_setjen'], 0, ',', '.')) : '-'));
		$this->excel->getActiveSheet()->setCellValue(('E'.$cnt_row), (!empty($this->_data['total_kebutuhan']) ? (number_format($this->_data['total_kebutuhan'], 0, ',', '.')) : '-'));
		$this->excel->getActiveSheet()->setCellValue(('F'.$cnt_row), (!empty($this->_data['total_tunjangan']) ? (number_format($this->_data['total_tunjangan'], 0, ',', '.')) : '-'));
		$this->excel->getActiveSheet()->setCellValue(('G'.$cnt_row), (!empty($this->_data['pajak']) ? (number_format($this->_data['pajak'], 0, ',', '.')) : '-'));
		$this->excel->getActiveSheet()->setCellValue(('H'.$cnt_row), (!empty($this->_data['bruto']) ? (number_format($this->_data['bruto'], 0, ',', '.')) : '-'));
		$this->excel->getActiveSheet()->setCellValue(('I'.$cnt_row), (!empty($this->_data['pajak']) ? (number_format($this->_data['pajak'], 0, ',', '.')) : '-'));
		$this->excel->getActiveSheet()->setCellValue(('J'.$cnt_row), (!empty($this->_data['total_potongan']) ? (number_format($this->_data['total_potongan'], 0, ',', '.')) : '-'));
		$this->excel->getActiveSheet()->setCellValue(('K'.$cnt_row), (!empty($this->_data['netto']) ? (number_format($this->_data['netto'], 0, ',', '.')) : '-'));
		$this->excel->getActiveSheet()->setCellValue(('L'.$cnt_row), (!empty($this->_data['sisa_dana']) ? (number_format($this->_data['sisa_dana'], 0, ',', '.')) : '-'));

		$cnt_row++;
		$no++;

		$this->excel->getActiveSheet()->getStyle(('C'.$cnt_row))->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);
		$this->excel->getActiveSheet()->getStyle(('D'.$cnt_row))->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);
		$this->excel->getActiveSheet()->getStyle(('E'.$cnt_row))->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);
		$this->excel->getActiveSheet()->getStyle(('F'.$cnt_row))->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);
		$this->excel->getActiveSheet()->getStyle(('G'.$cnt_row))->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);
		$this->excel->getActiveSheet()->getStyle(('H'.$cnt_row))->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);
		$this->excel->getActiveSheet()->getStyle(('I'.$cnt_row))->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);
		$this->excel->getActiveSheet()->getStyle(('J'.$cnt_row))->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);
		$this->excel->getActiveSheet()->getStyle(('K'.$cnt_row))->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);
		$this->excel->getActiveSheet()->getStyle(('L'.$cnt_row))->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);
		$this->excel->getActiveSheet()->getStyle('A'.$cnt_row.':L'.$cnt_row)->getFont()->setBold(true);

		$this->excel->getActiveSheet()->setCellValue(('A'.$cnt_row), 'Jumlah');
		$this->excel->getActiveSheet()->setCellValue(('C'.$cnt_row), (!empty($this->_data['txt_saldo_awal']) ? (number_format($this->_data['txt_saldo_awal'], 0, ',', '.')) : '-'));
		$this->excel->getActiveSheet()->setCellValue(('D'.$cnt_row), (!empty($this->_data['txt_transfer_setjen']) ? (number_format($this->_data['txt_transfer_setjen'], 0, ',', '.')) : '-'));
		$this->excel->getActiveSheet()->setCellValue(('E'.$cnt_row), (!empty($this->_data['total_kebutuhan']) ? (number_format($this->_data['total_kebutuhan'], 0, ',', '.')) : '-'));
		$this->excel->getActiveSheet()->setCellValue(('F'.$cnt_row), (!empty($this->_data['total_tunjangan']) ? (number_format($this->_data['total_tunjangan'], 0, ',', '.')) : '-'));
		$this->excel->getActiveSheet()->setCellValue(('G'.$cnt_row), (!empty($this->_data['pajak']) ? (number_format($this->_data['pajak'], 0, ',', '.')) : '-'));
		$this->excel->getActiveSheet()->setCellValue(('H'.$cnt_row), (!empty($this->_data['bruto']) ? (number_format($this->_data['bruto'], 0, ',', '.')) : '-'));
		$this->excel->getActiveSheet()->setCellValue(('I'.$cnt_row), (!empty($this->_data['pajak']) ? (number_format($this->_data['pajak'], 0, ',', '.')) : '-'));
		$this->excel->getActiveSheet()->setCellValue(('J'.$cnt_row), (!empty($this->_data['total_potongan']) ? (number_format($this->_data['total_potongan'], 0, ',', '.')) : '-'));
		$this->excel->getActiveSheet()->setCellValue(('K'.$cnt_row), (!empty($this->_data['netto']) ? (number_format($this->_data['netto'], 0, ',', '.')) : '-'));
		$this->excel->getActiveSheet()->setCellValue(('L'.$cnt_row), (!empty($this->_data['sisa_dana']) ? (number_format($this->_data['sisa_dana'], 0, ',', '.')) : '-'));

		//$this->excel->getActiveSheet()->getStyle('A1')->getFont()->setSize(20);

		$filename='report_rekap_lpj_'.time().'.xls'; //save our workbook as this file name
		header('Content-Type: application/vnd.ms-excel'); //mime type
		header('Content-Disposition: attachment;filename="'.$filename.'"'); //tell browser what's the file name
		header('Cache-Control: max-age=0'); //no cache
		            
		//save it to Excel5 format (excel 2003 .XLS file), change this to 'Excel2007' (and adjust the filename extension, also the header mime type)
		//if you want to save it as .XLSX Excel 2007 format
		$objWriter = PHPExcel_IOFactory::createWriter($this->excel, 'Excel5');  
		//force user to download the Excel file without writing it to server's HD
		$objWriter->save('php://output');
	}

	private function get_netto_karyawan() {
		$strtotime_tanggal_awal 	= strtotime(($this->_data['txt_tanggal_awal'] . ' 00:00:00'));
		$strtotime_tanggal_akhir 	= strtotime(($this->_data['txt_tanggal_akhir'] . ' 23:59:00'));

		$res_potongan 		= $this->report->get_all_sanksipotongan();
		$res_potongan_masuk = $this->report->order_by('sp_menit_awal', 'DESC')->get_all_sanksipotonganmasuk();
		$res_gakmasuk 		= $this->report->where(array('abs_tanggal >=' => $strtotime_tanggal_awal, 'abs_tanggal <=' => $strtotime_tanggal_akhir))->get_all_gakmasuk();
		$res_gakmasukmesin 	= $this->report->where(array('abs_tanggal >=' => $strtotime_tanggal_awal, 'abs_tanggal <=' => $strtotime_tanggal_akhir))->get_all_gakmasukmesin();
		$res_masuk 			= $this->report->where(array('nDateTime >=' => $strtotime_tanggal_awal, 'nDateTime <=' => $strtotime_tanggal_akhir))->get_all_masuk();
		
		$this->_data['potongan'] = array();

		$history = array();
		
		foreach ($res_masuk as $val) {
			$history[$val['nDateTime']][$val['id_karyawan']] = 1;

			if(!empty($res_gakmasuk[$val['id_karyawan']][$val['nDateTime']])) continue;
			if(!empty($res_gakmasukmesin[$val['id_karyawan']][$val['nDateTime']]['MT'])) $val['nLateInTime'] = 0;
			if(!empty($res_gakmasukmesin[$val['id_karyawan']][$val['nDateTime']]['PC'])) $val['nEarlyOutTime'] = 0;

			if(empty($val['nLateInTime']) AND empty($val['nEarlyOutTime'])) continue;

			if(empty($this->_data['potongan'][$val['id_karyawan']])) {
				$this->_data['potongan'][$val['id_karyawan']] = $this->get_potongan_absensi($val, $res_potongan_masuk);
			} else {
				$this->_data['potongan'][$val['id_karyawan']] += $this->get_potongan_absensi($val, $res_potongan_masuk);
			}
		}

		//hitung potongan karyawan yg gak masuk, yang beralasan kecuali karyawan masuk terlambat n pulang cepat
		foreach ($res_gakmasuk as $vId) {
			foreach ($vId as $val) {
				foreach ($val as $vAkhir) {
					$history[$vAkhir['abs_tanggal']][$vAkhir['id_karyawan']] = 1;

					if(empty($this->_data['potongan'][$vAkhir['id_karyawan']])) {
						$this->_data['potongan'][$vAkhir['id_karyawan']] = round(($vAkhir['tunjangan'] / 100) * $res_potongan[$vAkhir['jp_kode']][$vAkhir['id_sanksi_potongan']]['persentase']);
					} else {
						$this->_data['potongan'][$vAkhir['id_karyawan']] += round(($vAkhir['tunjangan'] / 100) * $res_potongan[$vAkhir['jp_kode']][$vAkhir['id_sanksi_potongan']]['persentase']);
					}
				}
			}
		}

		//hitung potongan karyawan yg gak masuk hanya karyawan masuk terlambat n pulang cepat
		foreach ($res_gakmasukmesin as $vId) {
			foreach ($vId as $vax) {
				foreach ($vax as $val) {
					foreach ($val as $vAkhir) {
						$history[$vAkhir['abs_tanggal']][$vAkhir['id_karyawan']] = 1;

						if(empty($this->_data['potongan'][$vAkhir['id_karyawan']])) {
							$this->_data['potongan'][$vAkhir['id_karyawan']] = round(($vAkhir['tunjangan'] / 100) * $res_potongan[$vAkhir['jp_kode']][$vAkhir['id_sanksi_potongan']]['persentase']);
						} else {
							$this->_data['potongan'][$vAkhir['id_karyawan']] += round(($vAkhir['tunjangan'] / 100) * $res_potongan[$vAkhir['jp_kode']][$vAkhir['id_sanksi_potongan']]['persentase']);
						}
					}
				}
			}
		}

		//hitung potongan karyawan yg gak masuk yang gak beralasan
		if(!empty($history)) {
			foreach ($this->_data['result'] as $key => $val) {
				foreach ($history as $kHistory => $vHistory) {
					if(!empty($history[$kHistory][$val['id_karyawan']])) continue;

					if(empty($this->_data['potongan'][$val['id_karyawan']])) {
						$this->_data['potongan'][$val['id_karyawan']] = round(($val['tunjangan'] / 100) * $res_potongan['TM'][1]['persentase']);
					} else {
						$this->_data['potongan'][$val['id_karyawan']] += round(($val['tunjangan'] / 100) * $res_potongan['TM'][1]['persentase']);
					}
				}
			}
		}
	}

	private function get_potongan_absensi($val, $res_potongan_masuk) {
		$potongan 	= 0;
		if($val['nLateInTime'] > 0) {
			foreach ($res_potongan_masuk['MT'][0] as $value) {
				if($val['nLateInTime'] >= $value['sp_menit_awal']) {
					$persentase = $value['persentase'];
					break;
				}
			}
			$potongan += round(($val['tunjangan'] / 100) * $persentase);
		}
		if($val['nEarlyOutTime'] > 0) {
			foreach ($res_potongan_masuk['PC'][0] as $value) {
				if($val['nEarlyOutTime'] >= $value['sp_menit_awal']) {
					$persentase = $value['persentase'];
					break;
				}
			}
			$potongan += round(($val['tunjangan'] / 100) * $persentase);
		}
		return $potongan;
	}

	function do_print() {
		$this->do_submit();

		$this->template->load('template_print/main_landscape', 'print', $this->_data);
	}
}

?>